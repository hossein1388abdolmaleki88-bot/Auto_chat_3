"""نقطه ورود اجرای ربات. اجرا: python main.py"""
from app.bot import run

if __name__ == "__main__":
    run()
