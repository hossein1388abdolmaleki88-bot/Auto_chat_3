"""
تست‌های Rule Engine طبق بخش ۳۳ Specification.
فقط از stdlib (unittest) استفاده می‌شود تا بدون نیاز به هیچ dependency خارجی
(SQLAlchemy / python-telegram-bot) قابل اجرا باشد.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.rule_engine import (
    EngineContext,
    EngineRule,
    FREE_DEFAULT_RULE,
    ResponseMediaType,
    TriggerType,
    match_rule,
)


def make_ctx(is_pro, text, rules):
    return EngineContext(
        is_pro=is_pro,
        incoming_text=text,
        rules=tuple(rules),
    )


class TestRuleEngine(unittest.TestCase):
    def test_01_salam_matches_free_rule(self):
        """۱. سلام → Match"""
        ctx = make_ctx(False, "سلام", [FREE_DEFAULT_RULE])
        matched = match_rule(ctx)
        self.assertIsNotNone(matched)
        self.assertEqual(matched.id, FREE_DEFAULT_RULE.id)

    def test_02_salam_correct_response(self):
        """۲. سلام → Response صحیح"""
        ctx = make_ctx(False, "سلام", [FREE_DEFAULT_RULE])
        matched = match_rule(ctx)
        self.assertEqual(matched.response_text, "سلام 👋\nممنون که با ما در ارتباط هستید.")

    def test_03_price_contains_match(self):
        """۳. قیمت → Contains Match"""
        price_rule = EngineRule(
            id=1,
            trigger_type=TriggerType.CONTAINS,
            trigger_value="قیمت",
            response_text="برای اطلاع از قیمت با ما تماس بگیرید.",
            response_media_type=ResponseMediaType.NONE,
        )
        ctx = make_ctx(True, "قیمت", [price_rule])
        matched = match_rule(ctx)
        self.assertIsNotNone(matched)
        self.assertEqual(matched.id, 1)

    def test_04_price_in_sentence_matches(self):
        """۴. قیمت محصول چنده؟ → Match"""
        price_rule = EngineRule(
            id=1,
            trigger_type=TriggerType.CONTAINS,
            trigger_value="قیمت",
            response_text="برای اطلاع از قیمت با ما تماس بگیرید.",
            response_media_type=ResponseMediaType.NONE,
        )
        ctx = make_ctx(True, "قیمت محصول چنده؟", [price_rule])
        matched = match_rule(ctx)
        self.assertIsNotNone(matched)
        self.assertEqual(matched.id, 1)

    def test_05_unrelated_message_no_match(self):
        """۵. پیام نامرتبط → No Match"""
        price_rule = EngineRule(
            id=1,
            trigger_type=TriggerType.CONTAINS,
            trigger_value="قیمت",
            response_text="...",
            response_media_type=ResponseMediaType.NONE,
        )
        ctx = make_ctx(True, "هواشناسی امروز چطوره؟", [price_rule, FREE_DEFAULT_RULE])
        matched = match_rule(ctx)
        self.assertIsNone(matched)

    def test_06_removed_first_message_no_longer_exists(self):
        """۶. (حذف قابلیت FIRST_MESSAGE) نوع شرط فقط EXACT و CONTAINS است."""
        with self.assertRaises(AttributeError):
            _ = TriggerType.FIRST_MESSAGE

    def test_07_free_plan_pro_rule_not_executed(self):
        """۷. Free → Pro Rule اجرا نشود"""
        pro_rule = EngineRule(
            id=3,
            trigger_type=TriggerType.CONTAINS,
            trigger_value="کرج",
            response_text="فرصت‌های شغلی کرج",
            response_media_type=ResponseMediaType.NONE,
            requires_pro=True,
        )
        ctx = make_ctx(False, "کرج", [pro_rule])
        matched = match_rule(ctx)
        self.assertIsNone(matched)

    def test_09_pro_active_pro_rule_executed(self):
        """۹. Pro فعال → Pro Rule اجرا شود"""
        pro_rule = EngineRule(
            id=3,
            trigger_type=TriggerType.CONTAINS,
            trigger_value="کرج",
            response_text="فرصت‌های شغلی کرج",
            response_media_type=ResponseMediaType.NONE,
            requires_pro=True,
        )
        ctx = make_ctx(True, "کرج", [pro_rule])
        matched = match_rule(ctx)
        self.assertIsNotNone(matched)
        self.assertEqual(matched.id, 3)

    def test_10_pro_expired_pro_rule_not_executed(self):
        """۱۰. Pro منقضی → Pro Rule اجرا نشود (is_pro=False چون منقضی شده)"""
        pro_rule = EngineRule(
            id=3,
            trigger_type=TriggerType.CONTAINS,
            trigger_value="کرج",
            response_text="فرصت‌های شغلی کرج",
            response_media_type=ResponseMediaType.NONE,
            requires_pro=True,
        )
        # is_pro=False شبیه‌سازی می‌کند که BusinessAccount.is_pro_active() منقضی شده و False برگردانده
        ctx = make_ctx(False, "کرج", [pro_rule])
        matched = match_rule(ctx)
        self.assertIsNone(matched)

    def test_11_duplicate_message_not_processed_again(self):
        """۱۱. Duplicate Message → دوباره اجرا نشود (منطق dedup در MessageLog/repository است)"""
        seen_message_ids: set[tuple[int, int]] = set()

        def process_once(business_account_id: int, telegram_message_id: int) -> bool:
            key = (business_account_id, telegram_message_id)
            if key in seen_message_ids:
                return False
            seen_message_ids.add(key)
            return True

        self.assertTrue(process_once(1, 555))
        self.assertFalse(process_once(1, 555))

    def test_12_bot_outgoing_message_not_reprocessed(self):
        """۱۲. Bot Outgoing Message → دوباره پردازش نشود"""

        def should_process(is_from_bot: bool) -> bool:
            return not is_from_bot

        self.assertFalse(should_process(is_from_bot=True))
        self.assertTrue(should_process(is_from_bot=False))

    def test_13_photo_rule_matches_with_photo_media_type(self):
        """۱۳. Photo Rule → عکس ارسال شود (نتیجه: matched rule دارای media_type=PHOTO)"""
        photo_rule = EngineRule(
            id=4,
            trigger_type=TriggerType.CONTAINS,
            trigger_value="نمونه کار",
            response_text=None,
            response_media_type=ResponseMediaType.PHOTO,
        )
        ctx = make_ctx(True, "نمونه کار دارید؟", [photo_rule])
        matched = match_rule(ctx)
        self.assertIsNotNone(matched)
        self.assertEqual(matched.response_media_type, ResponseMediaType.PHOTO)

    def test_14_multiple_photo_rule(self):
        """۱۴. Multiple Photo Rule → چند عکس ارسال شود"""
        from app.rule_engine import RuleMediaItem

        multi_photo_rule = EngineRule(
            id=5,
            trigger_type=TriggerType.CONTAINS,
            trigger_value="کرج",
            response_text="فرصت‌های شغلی کرج 👇",
            response_media_type=ResponseMediaType.TEXT_AND_PHOTOS,
            media_items=(
                RuleMediaItem("file_id_1", 0),
                RuleMediaItem("file_id_2", 1),
                RuleMediaItem("file_id_3", 2),
            ),
        )
        ctx = make_ctx(True, "کرج", [multi_photo_rule])
        matched = match_rule(ctx)
        self.assertIsNotNone(matched)
        self.assertEqual(len(matched.media_items), 3)
        self.assertEqual([m.telegram_file_id for m in matched.media_items], ["file_id_1", "file_id_2", "file_id_3"])

    def test_15_text_and_photo_rule(self):
        """۱۵. Text + Photo → متن و عکس ارسال شود"""
        from app.rule_engine import RuleMediaItem

        rule = EngineRule(
            id=6,
            trigger_type=TriggerType.CONTAINS,
            trigger_value="کرج",
            response_text="فرصت‌های شغلی کرج 👇",
            response_media_type=ResponseMediaType.TEXT_AND_PHOTOS,
            media_items=(RuleMediaItem("file_id_1", 0),),
        )
        ctx = make_ctx(True, "کرج", [rule])
        matched = match_rule(ctx)
        self.assertIsNotNone(matched)
        self.assertTrue(matched.response_text)
        self.assertTrue(len(matched.media_items) >= 1)

    # --- تست‌های تکمیلی برای priority و ترتیب بررسی (EXACT > CONTAINS) ---

    def test_priority_exact_over_contains(self):
        exact_rule = EngineRule(
            id=20,
            trigger_type=TriggerType.EXACT,
            trigger_value="قیمت",
            response_text="پاسخ دقیق",
            response_media_type=ResponseMediaType.NONE,
        )
        contains_rule = EngineRule(
            id=21,
            trigger_type=TriggerType.CONTAINS,
            trigger_value="قیمت",
            response_text="پاسخ عمومی",
            response_media_type=ResponseMediaType.NONE,
        )
        ctx = make_ctx(True, "قیمت", [exact_rule, contains_rule])
        matched = match_rule(ctx)
        self.assertEqual(matched.id, 20)

    def test_disabled_rule_not_matched(self):
        disabled_rule = EngineRule(
            id=30,
            trigger_type=TriggerType.CONTAINS,
            trigger_value="تست",
            response_text="...",
            response_media_type=ResponseMediaType.NONE,
            enabled=False,
        )
        ctx = make_ctx(True, "تست", [disabled_rule])
        matched = match_rule(ctx)
        self.assertIsNone(matched)


if __name__ == "__main__":
    unittest.main()
