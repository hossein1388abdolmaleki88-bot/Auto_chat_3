"""
تست‌های تبدیل تاریخ شمسی (app/timeutil.py) — از نسخه‌ی ۱۴۰۵/۰۶/۱۰ که همه‌ی
تاریخ‌های نمایشی بات شمسی می‌شوند.

الگوریتم جلالی با کتابخانه‌ی مرجع jdatetime برای همه‌ی روزهای ۱۹۰۰ تا ۲۱۰۰
میلادی (۷۳٬۴۱۴ روز) صحت‌سنجی شده؛ این تست‌ها فقط چند نقطه‌ی مرجع معروف و
رفتار format_iran را چک می‌کنند.
"""
import sys
import unittest
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.timeutil import days_left_until, fa_digits, format_iran, gregorian_to_jalali


class GregorianToJalaliTest(unittest.TestCase):
    def test_known_dates(self):
        cases = [
            # (میلادی) → (شمسی) — نقاط مرجع شناخته‌شده
            ((1979, 2, 11), (1357, 11, 22)),   # پیروزی انقلاب اسلامی
            ((2000, 1, 1), (1378, 10, 11)),    # شروع سال ۲۰۰۰
            ((2024, 3, 20), (1403, 1, 1)),     # نوروز ۱۴۰۳
            ((2025, 3, 21), (1404, 1, 1)),     # نوروز ۱۴۰۴
            ((2026, 3, 21), (1405, 1, 1)),     # نوروز ۱۴۰۵
            ((2026, 8, 31), (1405, 6, 9)),     # امروزِ تست‌ها
            ((2026, 9, 22), (1405, 6, 31)),    # آخرین روز شهریور (۶ ماهِ اول ۳۱ روزه)
            ((2026, 9, 23), (1405, 7, 1)),     # شروع مهر
            ((2027, 3, 20), (1405, 12, 29)),   # آخرین روز اسفند ۱۴۰۵ (سال ۱۴۰۵ کبیسه نیست)
        ]
        for (gy, gm, gd), expected in cases:
            self.assertEqual(gregorian_to_jalali(gy, gm, gd), expected)

    def test_month_boundaries(self):
        # ۳۰ آبان ۱۴۰۵ = ۲۱ نوامبر ۲۰۲۶ (ماه‌های دومِ نیمه‌ی دوم ۳۰ روزه‌اند)
        self.assertEqual(gregorian_to_jalali(2026, 11, 21), (1405, 8, 30))
        # ۱ آذر = ۲۲ نوامبر
        self.assertEqual(gregorian_to_jalali(2026, 11, 22), (1405, 9, 1))


class FormatIranShamsiTest(unittest.TestCase):
    def test_default_format_with_persian_digits(self):
        # 2026-08-31 11:00 UTC = 14:30 به وقت تهران (همان روز)
        dt = datetime(2026, 8, 31, 11, 0, tzinfo=timezone.utc)
        self.assertEqual(format_iran(dt), "۱۴۰۵/۰۶/۰۹ ۱۴:۳۰")

    def test_date_only_format(self):
        dt = datetime(2026, 8, 31, 11, 0, tzinfo=timezone.utc)
        self.assertEqual(format_iran(dt, fmt="%Y/%m/%d"), "۱۴۰۵/۰۶/۰۹")
        self.assertEqual(format_iran(dt, fmt="%Y-%m-%d"), "۱۴۰۵-۰۶-۰۹")

    def test_latin_digits_option(self):
        dt = datetime(2026, 8, 31, 11, 0, tzinfo=timezone.utc)
        self.assertEqual(format_iran(dt, persian_digits=False), "1405/06/09 14:30")

    def test_none_returns_fallback(self):
        self.assertEqual(format_iran(None), "-")
        self.assertEqual(format_iran(None, fallback="ندارد"), "ندارد")

    def test_naive_utc_input(self):
        # ورودی naive (مثل چیزی که در دیتابیس ذخیره می‌شود) هم UTC فرض می‌شود
        dt = datetime(2026, 8, 31, 11, 0)
        self.assertEqual(format_iran(dt, fmt="%Y/%m/%d"), "۱۴۰۵/۰۶/۰۹")


class FaDigitsTest(unittest.TestCase):
    def test_digits_conversion(self):
        self.assertEqual(fa_digits(30), "۳۰")
        self.assertEqual(fa_digits(0), "۰")
        self.assertEqual(fa_digits("1405/06/09"), "۱۴۰۵/۰۶/۰۹")


class DaysLeftUntilTest(unittest.TestCase):
    def test_future_date(self):
        from datetime import timedelta

        future = datetime.utcnow() + timedelta(days=32)
        # بر اساس اختلاف تقویمی: دقیقاً ۳۲ روز بعد → ۳۲ (پایدار و بدون حساسیت به زمان اجرا)
        self.assertEqual(days_left_until(future), 32)

    def test_two_days_remaining(self):
        from datetime import timedelta

        future = datetime.utcnow() + timedelta(days=2)
        self.assertEqual(days_left_until(future), 2)

    def test_none_returns_zero(self):
        self.assertEqual(days_left_until(None), 0)


if __name__ == "__main__":
    unittest.main()
