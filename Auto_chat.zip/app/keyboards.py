"""
سازنده‌های Reply Keyboard.

طبق درخواست کاربر، دکمه‌ها باید در کیبورد پایین صفحه (Reply Keyboard) باشند نه
زیر پیام (Inline Keyboard)، طوری که وقتی کاربر «بازگشت» می‌زند، دکمه‌های سطح
قبلی دوباره ظاهر شوند.

محدودیت مهم Telegram API: KeyboardButton (بر خلاف InlineKeyboardButton) نمی‌تواند
لینک (url) داشته باشد. برای لینک‌هایی مثل «عضویت در کانال» یا «چت با ادمین»، لینک
به‌صورت متن قابل‌کلیک (Telegram خودش لینک‌های t.me را Auto-Link می‌کند) داخل پیام
نوشته می‌شود؛ دکمه‌ها فقط برای اکشن‌های داخلی بات (بررسی مجدد، بازگشت و غیره)
استفاده می‌شوند.

هر دکمه‌ی دارای شناسه‌ی پویا (مثل ردیف‌های Rule یا کاربر) با پیشوند "#<id> "
ساخته می‌شود تا در روتر پیام‌های متنی بتوان id را استخراج کرد.
"""
from __future__ import annotations

import re

from telegram import KeyboardButton, ReplyKeyboardMarkup

from app import texts
from app.models import BusinessAccount, ForceJoinChannel, Rule

_ID_PATTERN = re.compile(r"#(\d+)")


def extract_id(text: str) -> int | None:
    """استخراج شناسه عددی از برچسب دکمه‌های پویا (مثل '🟢 #12 CONTAINS: کرج')."""
    match = _ID_PATTERN.search(text)
    if not match:
        return None
    return int(match.group(1))


def _kb(rows: list[list[str]]) -> ReplyKeyboardMarkup:
    button_rows = [[KeyboardButton(label) for label in row] for row in rows]
    return ReplyKeyboardMarkup(button_rows, resize_keyboard=True)


def main_menu_keyboard(has_business_account: bool, is_admin: bool) -> ReplyKeyboardMarkup:
    """
    دکمه «🔗 اتصال اکانت تلگرام» فقط وقتی نمایش داده می‌شود که کاربر هنوز هیچ
    Business Account متصل‌شده‌ای نداشته باشد (طبق درخواست ادمین)؛ به محض اینکه
    اتصال برقرار شود، این دکمه از منو حذف می‌شود تا کاربر دوباره وصل نشود و
    حساب تکراری ساخته نشود. اگر کاربر دسترسی بات را قطع کند، اکانت از دیتابیس
    حذف می‌شود و دکمه‌ی اتصال دوباره ظاهر می‌شود.

    دکمه «⚙️ مدیریت قوانین» برای هر کاربری که حداقل یک Business Account متصل
    دارد نمایش داده می‌شود — نه فقط Pro — چون کاربران Free هم می‌توانند هم
    قانون رایگان «سلام» را فعال/غیرفعال کنند و هم (تا سقف مجاز خودشان) قانون
    اختصاصی بسازند؛ Pro/Pro Max فقط سقف را بالاتر/نامحدود می‌برند.
    """
    if has_business_account:
        rows = [[texts.BTN_BUY_PRO], [texts.BTN_ACCOUNT, texts.BTN_HELP]]
        rows.append([texts.BTN_MANAGE_RULES])
    else:
        rows = [
            [texts.BTN_CONNECT, texts.BTN_BUY_PRO],
            [texts.BTN_ACCOUNT, texts.BTN_HELP],
        ]
    if is_admin:
        rows.append([texts.BTN_ADMIN_PANEL])
    return _kb(rows)


def buy_plan_choice_keyboard() -> ReplyKeyboardMarkup:
    return _kb([[texts.BTN_PLAN_PRO, texts.BTN_PLAN_PRO_MAX], [texts.BTN_BACK_TO_MENU]])


def pricing_duration_option_label(duration_days: int, price: int, pricing_id: int) -> str:
    return f"{duration_days} روز — {price:,} تومان #{pricing_id}"


def buy_duration_keyboard(options: list) -> ReplyKeyboardMarkup:
    """options: list[PricingPlan] (فقط enabled) برای پلن انتخاب‌شده."""
    rows = [[pricing_duration_option_label(opt.duration_days, opt.price, opt.id)] for opt in options]
    rows.append([texts.BTN_BACK_TO_MENU])
    return _kb(rows)


def back_to_menu_keyboard() -> ReplyKeyboardMarkup:
    return _kb([[texts.BTN_BACK_TO_MENU]])


def cancel_only_keyboard() -> ReplyKeyboardMarkup:
    return _kb([[texts.BTN_CANCEL]])


def force_join_keyboard() -> ReplyKeyboardMarkup:
    return _kb([[texts.BTN_FORCE_JOIN_CHECK]])


def force_join_links_text(channels: list[ForceJoinChannel]) -> str:
    lines = []
    for ch in channels:
        link = ch.invite_link or (
            f"https://t.me/{ch.channel_id.lstrip('@')}" if ch.channel_id.startswith("@") else ch.channel_id
        )
        lines.append(f"📢 {ch.title or ch.channel_id}\n{link}")
    return "\n\n".join(lines)


# --- مدیریت قوانین (کاربر Pro) ---


def rule_button_label(rule: Rule) -> str:
    value = (rule.trigger_value or rule.trigger_type.value)[:24]
    status_icon = "🟢" if rule.enabled else "🔴"
    return f"{status_icon} #{rule.id} {rule.trigger_type.value}: {value}"


def rules_list_keyboard(custom_rules: list[Rule], free_rule_enabled: bool) -> ReplyKeyboardMarkup:
    rows = [[texts.BTN_FREE_HELLO_RULE_ON if free_rule_enabled else texts.BTN_FREE_HELLO_RULE_OFF]]
    for rule in custom_rules:
        rows.append([rule_button_label(rule)])
    rows.append([texts.BTN_RULE_ADD])
    rows.append([texts.BTN_BACK_TO_MENU])
    return _kb(rows)


def rule_detail_keyboard(rule: Rule) -> ReplyKeyboardMarkup:
    rows = []
    if not rule.is_system:
        rows.append([texts.BTN_RULE_TOGGLE])
        rows.append([texts.BTN_RULE_DELETE])
    rows.append([texts.BTN_BACK_TO_RULES])
    return _kb(rows)


def trigger_type_keyboard() -> ReplyKeyboardMarkup:
    return _kb(
        [
            [texts.BTN_TRIGGER_EXACT],
            [texts.BTN_TRIGGER_CONTAINS],
            [texts.BTN_CANCEL],
        ]
    )


def photo_step_keyboard() -> ReplyKeyboardMarkup:
    return _kb([[texts.BTN_PHOTOS_DONE], [texts.BTN_CANCEL]])


# --- Admin ---


def admin_panel_keyboard() -> ReplyKeyboardMarkup:
    return _kb(
        [
            [texts.BTN_ADMIN_USERS, texts.BTN_ADMIN_PRICE],
            [texts.BTN_ADMIN_RULE_LIMITS, texts.BTN_ADMIN_BROADCAST],
            [texts.BTN_ADMIN_FORCE_JOIN, texts.BTN_ADMIN_STATS],
            [texts.BTN_ADMIN_CONTENT, texts.BTN_ADMIN_BACKUP_NOW],
            [texts.BTN_BACK_TO_MENU],
        ]
    )


def admin_back_keyboard() -> ReplyKeyboardMarkup:
    return _kb([[texts.BTN_ADMIN_BACK]])


def admin_user_detail_keyboard(account: BusinessAccount) -> ReplyKeyboardMarkup:
    rows = []
    if account.plan.value in ("PRO", "PRO_MAX"):
        rows.append([texts.BTN_ADMIN_RENEW_PRO])
        rows.append([texts.BTN_ADMIN_CANCEL_PRO])
    else:
        rows.append([texts.BTN_ADMIN_ACTIVATE_PRO])
    rows.append([texts.BTN_ADMIN_DELETE_USER])
    rows.append([texts.BTN_ADMIN_BACK])
    return _kb(rows)


def admin_user_delete_confirm_keyboard() -> ReplyKeyboardMarkup:
    return _kb([[texts.BTN_ADMIN_DELETE_USER_CONFIRM], [texts.BTN_ADMIN_BACK]])


def admin_activate_plan_choice_keyboard() -> ReplyKeyboardMarkup:
    return _kb([[texts.BTN_PLAN_PRO, texts.BTN_PLAN_PRO_MAX], [texts.BTN_ADMIN_BACK]])


def admin_activate_duration_keyboard(options: list) -> ReplyKeyboardMarkup:
    rows = [[pricing_duration_option_label(opt.duration_days, opt.price, opt.id)] for opt in options]
    rows.append([texts.BTN_ADMIN_BACK])
    return _kb(rows)


def admin_price_menu_keyboard() -> ReplyKeyboardMarkup:
    return _kb(
        [
            [texts.BTN_ADMIN_MANAGE_PRICING],
            [texts.BTN_ADMIN_EDIT_PRICE, texts.BTN_ADMIN_EDIT_DURATION],
            [texts.BTN_ADMIN_BACK],
        ]
    )


def admin_rule_limits_keyboard() -> ReplyKeyboardMarkup:
    return _kb(
        [
            [texts.BTN_ADMIN_EDIT_RULE_LIMIT],
            [texts.BTN_ADMIN_EDIT_PRO_RULE_LIMIT],
            [texts.BTN_ADMIN_BACK],
        ]
    )


def admin_content_keyboard() -> ReplyKeyboardMarkup:
    return _kb(
        [
            [texts.BTN_ADMIN_EDIT_SUPPORT_USERNAME],
            [texts.BTN_ADMIN_EDIT_HELP_TEXT],
            [texts.BTN_ADMIN_BACK],
        ]
    )


def admin_edit_help_text_keyboard() -> ReplyKeyboardMarkup:
    return _kb([[texts.BTN_ADMIN_RESET_HELP_TEXT], [texts.BTN_ADMIN_BACK]])


def admin_broadcast_confirm_keyboard() -> ReplyKeyboardMarkup:
    return _kb([[texts.BTN_ADMIN_BROADCAST_SEND], [texts.BTN_ADMIN_BROADCAST_CANCEL]])


def admin_pricing_option_label(plan_value: str, duration_days: int, price: int, pricing_id: int) -> str:
    """
    نکته مهم: عمداً مقادیر ساده (str/int) می‌گیرد، نه خودِ آبجکت ORM «PricingPlan».
    این تابع قبلاً مستقیم آبجکت ORM می‌گرفت و در صورت فراخوانی بعد از بسته‌شدن
    session، با DetachedInstanceError کرش می‌کرد (چون attributeهای ORM بدون
    session زنده قابل خواندن نیستند مگر expire_on_commit=False تنظیم شده باشد).
    با گرفتن مقادیر ساده، این تابع دیگر به هیچ session‌ای وابسته نیست و کرش این
    کلاس اصلاً ممکن نیست — صرف‌نظر از اینکه فراخواننده کِی/کجا صدایش بزند.
    """
    plan_name = "Pro Max" if plan_value == "PRO_MAX" else "Pro"
    return f"{plan_name} — {duration_days} روز — {price:,} تومان #{pricing_id}"


def admin_pricing_list_keyboard(options: list) -> ReplyKeyboardMarkup:
    """
    options: list of plain (id, plan_value, duration_days, price) tuples — نه
    خودِ آبجکت‌های ORM. عمداً این‌طور طراحی شده تا این تابع اصلاً به عمر session
    وابسته نباشد؛ تبدیل PricingPlan → tuple باید توسط فراخواننده (همان‌جا که
    session هنوز باز است) انجام شود، نه اینجا.
    """
    rows = [
        [admin_pricing_option_label(plan_value, duration_days, price, pricing_id)]
        for (pricing_id, plan_value, duration_days, price) in options
    ]
    rows.append([texts.BTN_ADMIN_BACK])
    return _kb(rows)


def admin_force_join_keyboard(enabled: bool) -> ReplyKeyboardMarkup:
    toggle_label = texts.BTN_ADMIN_FJ_TOGGLE_OFF if enabled else texts.BTN_ADMIN_FJ_TOGGLE_ON
    return _kb(
        [
            [toggle_label],
            [texts.BTN_ADMIN_FJ_ADD_CHANNEL],
            [texts.BTN_ADMIN_FJ_LIST_CHANNELS],
            [texts.BTN_ADMIN_BACK],
        ]
    )


def force_join_channel_button_label(channel: ForceJoinChannel) -> str:
    return f"🗑 #{channel.id} {channel.title or channel.channel_id}"


def admin_force_join_channels_keyboard(channels: list[ForceJoinChannel]) -> ReplyKeyboardMarkup:
    rows = [[force_join_channel_button_label(ch)] for ch in channels]
    rows.append([texts.BTN_ADMIN_BACK])
    return _kb(rows)
