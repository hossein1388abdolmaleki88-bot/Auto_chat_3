"""
مدیریت وضعیت منو در context.user_data.

چون از Reply Keyboard استفاده می‌شود (نه Inline)، هیچ callback_data ای برای
تشخیص «کاربر الان کجای منو هست» وجود ندارد؛ بنابراین وضعیت فعلی باید در
user_data نگه‌داری شود تا روتر پیام‌های متنی بداند دکمه‌ی فشرده‌شده را با کدام
منو تطبیق دهد.
"""
from __future__ import annotations

from telegram.ext import ContextTypes

MENU_KEY = "menu"

# مقادیر ممکن برای MENU_KEY:
MENU_MAIN = "main"
MENU_RULES = "rules"
MENU_RULE_DETAIL = "rule_detail"
MENU_RULE_ADD_TRIGGER_TYPE = "rule_add_trigger_type"
MENU_RULE_ADD_TRIGGER_VALUE = "rule_add_trigger_value"
MENU_RULE_ADD_RESPONSE_TEXT = "rule_add_response_text"
MENU_RULE_ADD_PHOTOS = "rule_add_photos"
MENU_ADMIN = "admin"
MENU_ADMIN_USERS = "admin_users"
MENU_ADMIN_USER_DETAIL = "admin_user_detail"
MENU_ADMIN_USER_DELETE_CONFIRM = "admin_user_delete_confirm"
MENU_ADMIN_PRICE = "admin_price"
MENU_ADMIN_EDIT_PRICE = "admin_edit_price"
MENU_ADMIN_EDIT_DURATION = "admin_edit_duration"
MENU_ADMIN_EDIT_RULE_LIMIT = "admin_edit_rule_limit"
MENU_ADMIN_EDIT_PRO_RULE_LIMIT = "admin_edit_pro_rule_limit"
MENU_ADMIN_RULE_LIMITS = "admin_rule_limits"
MENU_ADMIN_BROADCAST_COMPOSE = "admin_broadcast_compose"
MENU_ADMIN_BROADCAST_CONFIRM = "admin_broadcast_confirm"
MENU_ADMIN_CONTENT = "admin_content"
MENU_ADMIN_EDIT_SUPPORT_USERNAME = "admin_edit_support_username"
MENU_ADMIN_EDIT_HELP_TEXT = "admin_edit_help_text"
MENU_ADMIN_PRICING_LIST = "admin_pricing_list"
MENU_ADMIN_PRICING_EDIT = "admin_pricing_edit"
MENU_ADMIN_FORCE_JOIN = "admin_force_join"
MENU_ADMIN_FORCE_JOIN_LIST = "admin_force_join_list"
MENU_ADMIN_FJ_ADD_CHANNEL = "admin_fj_add_channel"
MENU_ADMIN_ACTIVATE_PLAN_CHOICE = "admin_activate_plan_choice"
MENU_ADMIN_ACTIVATE_DURATION_CHOICE = "admin_activate_duration_choice"
MENU_BUY_PLAN_CHOICE = "buy_plan_choice"
MENU_BUY_DURATION_CHOICE = "buy_duration_choice"

CURRENT_RULE_ID = "current_rule_id"
ADMIN_SELECTED_ACCOUNT_ID = "admin_selected_account_id"
ADMIN_SELECTED_PRICING_ID = "admin_selected_pricing_id"
ADMIN_ACTIVATE_PLAN = "admin_activate_plan"
BUY_SELECTED_PLAN = "buy_selected_plan"
RULE_ADD_DRAFT = "rule_add_draft"
ADMIN_BROADCAST_DRAFT = "admin_broadcast_draft"


def get_menu(context: ContextTypes.DEFAULT_TYPE) -> str:
    return context.user_data.get(MENU_KEY, MENU_MAIN)


def set_menu(context: ContextTypes.DEFAULT_TYPE, menu: str) -> None:
    context.user_data[MENU_KEY] = menu


def clear_rule_add_draft(context: ContextTypes.DEFAULT_TYPE) -> None:
    context.user_data.pop(RULE_ADD_DRAFT, None)
