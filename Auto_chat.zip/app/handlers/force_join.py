"""بررسی عضویت اجباری پیش از اجازه استفاده از منوی اصلی ربات (بخش ۱۰)."""
from __future__ import annotations

from telegram import Update
from telegram.ext import ContextTypes

from app import keyboards, texts
from app.database import get_session
from app.repository import is_force_join_enabled, list_force_join_channels
from app.services.force_join_service import check_all_memberships


async def ensure_membership_or_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """
    اگر Force Join فعال باشد و کاربر عضو همه کانال‌ها نباشد، پیام عضویت اجباری نمایش
    داده و False برمی‌گرداند (یعنی جریان عادی باید متوقف شود).
    در غیر این‌صورت True برمی‌گرداند.
    """
    with get_session() as session:
        if not is_force_join_enabled(session):
            return True
        channels = list_force_join_channels(session, only_enabled=True)
        if not channels:
            return True

    tg_user = update.effective_user
    is_member, not_joined = await check_all_memberships(context.bot, channels, tg_user.id)
    if is_member:
        return True

    message = update.effective_message
    links = keyboards.force_join_links_text(not_joined)
    await message.reply_text(
        texts.FORCE_JOIN_PROMPT.format(links=links), reply_markup=keyboards.force_join_keyboard()
    )
    return False


async def force_join_check_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    with get_session() as session:
        channels = list_force_join_channels(session, only_enabled=True)

    tg_user = update.effective_user
    is_member, not_joined = await check_all_memberships(context.bot, channels, tg_user.id)

    if is_member:
        await update.effective_message.reply_text(texts.FORCE_JOIN_SUCCESS)
        from app.handlers.user_handlers import show_main_menu

        await show_main_menu(update, context)
    else:
        links = keyboards.force_join_links_text(not_joined)
        await update.effective_message.reply_text(
            texts.FORCE_JOIN_NOT_COMPLETE.format(links=links),
            reply_markup=keyboards.force_join_keyboard(),
        )
