"""
مدیریت قوانین اختصاصی + امکان فعال/غیرفعال کردن قانون رایگان «سلام».

مدل Free/Pro/Pro Max برای قوانین اختصاصی:
    هر سه پلن می‌توانند قانون اختصاصی بسازند، اما هرکدام سقف خودش را دارد
    (`get_rule_limit_for_account`؛ قابل تنظیم از پنل ادمین → «💰 قیمت Pro»):
    Free → `free_rule_limit` (پیش‌فرض ۲)، Pro → `pro_rule_limit` (پیش‌فرض ۱۵)،
    Pro Max → همیشه نامحدود. رولی که یک کاربر غیر-Max در سقف مجاز خودش می‌سازد
    `requires_pro=False` دارد تا واقعاً هم اجرا شود (نه فقط ذخیره شود)؛ در
    غیر این‌صورت Rule Engine (app/rule_engine.py) آن را نادیده می‌گرفت. برای
    کاربر Pro/Pro Max واقعی، `requires_pro=True` می‌ماند تا اگر پلن منقضی شد
    رول هم غیرفعال شود (انگیزه تمدید).

نکته مهم درباره Rule «سلام»:
    این Rule از نوع EXACT است. بنابراین طبق طراحی Rule Engine
    (app/rule_engine.py)، برای *هر* پیامی که دقیقاً برابر «سلام» باشد اجرا
    می‌شود — چه این اولین پیام آن مشتری با کسب‌وکار باشد، چه مشتری قبلاً هم
    پیام داده باشد.

معماری وضعیت (State Machine ساده مبتنی بر context.user_data، به‌جای
ConversationHandler، برای سازگاری با Reply Keyboard):

    MENU_RULES              → لیست قوانین + دکمه فعال/غیرفعال «سلام»
    MENU_RULE_DETAIL         → جزئیات یک قانون اختصاصی خاص
    MENU_RULE_ADD_TRIGGER_TYPE   → انتخاب نوع شرط
    MENU_RULE_ADD_TRIGGER_VALUE  → تایپ عبارت
    MENU_RULE_ADD_RESPONSE_TEXT  → تایپ متن پاسخ
    MENU_RULE_ADD_PHOTOS         → افزودن عکس(ها)
"""
from __future__ import annotations

from telegram import Update
from telegram.ext import ContextTypes

from app import keyboards, texts
from app.database import get_session
from app.handlers import state
from app.models import BusinessAccount, Rule, TriggerType
from app.repository import (
    business_account_is_pro,
    count_custom_rules,
    create_rule,
    delete_rule,
    get_business_accounts_for_user,
    get_or_create_user,
    get_rule_limit_for_account,
    list_rules,
    plan_label,
    toggle_rule,
)
from app.services.media_service import TELEGRAM_MEDIA_GROUP_MAX


def _get_any_account_id_sync(session, telegram_user_id: int) -> int | None:
    """برای دسترسی به Rule رایگان «سلام»، Pro لازم نیست — هر Business Account کافی است."""
    user = get_or_create_user(session, telegram_user_id=telegram_user_id)
    accounts = get_business_accounts_for_user(session, user.id)
    return accounts[0].id if accounts else None


def _get_any_account_sync(session, telegram_user_id: int) -> BusinessAccount | None:
    """اکانت Business کاربر (اگر باشد) — برای منطق سقف قانون هر پلن لازم است."""
    user = get_or_create_user(session, telegram_user_id=telegram_user_id)
    accounts = get_business_accounts_for_user(session, user.id)
    return accounts[0] if accounts else None


async def show_rules_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    tg_user = update.effective_user
    with get_session() as session:
        account = _get_any_account_sync(session, tg_user.id)
        if account is None:
            await update.effective_message.reply_text(
                texts.NO_BUSINESS_CONNECTION, reply_markup=keyboards.back_to_menu_keyboard()
            )
            state.set_menu(context, state.MENU_MAIN)
            return
        account_id = account.id

        rules = list_rules(session, account_id)
        system_rule = next((r for r in rules if r.is_system), None)
        custom_rules = [r for r in rules if not r.is_system]
        free_rule_enabled = system_rule.enabled if system_rule else True

        limit = get_rule_limit_for_account(session, account)
        label = plan_label(account)

        text = texts.RULES_LIST_HEADER
        if not custom_rules:
            text += texts.RULES_LIST_EMPTY_NOTE
        if limit is None:
            text += texts.RULES_LIST_UNLIMITED_NOTE.format(plan=label)
        else:
            text += texts.RULES_LIST_QUOTA_NOTE.format(plan=label, used=len(custom_rules), limit=limit)
        keyboard = keyboards.rules_list_keyboard(custom_rules, free_rule_enabled)

    state.set_menu(context, state.MENU_RULES)
    await update.effective_message.reply_text(text, reply_markup=keyboard)


async def handle_rules_menu_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    tg_user = update.effective_user

    if text in (texts.BTN_FREE_HELLO_RULE_ON, texts.BTN_FREE_HELLO_RULE_OFF):
        with get_session() as session:
            account_id = _get_any_account_id_sync(session, tg_user.id)
            if account_id is None:
                return True
            rules = list_rules(session, account_id)
            system_rule = next((r for r in rules if r.is_system), None)
            if system_rule is not None:
                toggle_rule(session, system_rule, not system_rule.enabled)
        await show_rules_menu(update, context)
        return True

    if text == texts.BTN_RULE_ADD:
        with get_session() as session:
            account = _get_any_account_sync(session, tg_user.id)
            if account is None:
                await update.effective_message.reply_text(
                    texts.NO_BUSINESS_CONNECTION, reply_markup=keyboards.back_to_menu_keyboard()
                )
                return True
            account_id = account.id
            is_pro = business_account_is_pro(account)
            limit = get_rule_limit_for_account(session, account)
            if limit is not None:
                used = count_custom_rules(session, account_id)
                if used >= limit:
                    await update.effective_message.reply_text(
                        texts.RULE_ADD_LIMIT_REACHED.format(plan=plan_label(account), limit=limit),
                        reply_markup=keyboards.back_to_menu_keyboard(),
                    )
                    return True
        context.user_data[state.RULE_ADD_DRAFT] = {
            "business_account_id": account_id,
            "photo_file_ids": [],
            "requires_pro": is_pro,
        }
        state.set_menu(context, state.MENU_RULE_ADD_TRIGGER_TYPE)
        await update.effective_message.reply_text(
            texts.RULE_ADD_INTRO, reply_markup=keyboards.trigger_type_keyboard()
        )
        return True

    rule_id = keyboards.extract_id(text)
    if rule_id is not None:
        await _show_rule_detail(update, context, rule_id)
        return True

    return False


async def _show_rule_detail(update: Update, context: ContextTypes.DEFAULT_TYPE, rule_id: int) -> None:
    with get_session() as session:
        rule = session.get(Rule, rule_id)
        if rule is None:
            await update.effective_message.reply_text(
                texts.RULE_NOT_FOUND, reply_markup=keyboards.back_to_menu_keyboard()
            )
            return
        photos_count = len(rule.media_items)
        detail = texts.RULE_DETAIL_TEMPLATE.format(
            trigger_type=rule.trigger_type.value,
            trigger_value=rule.trigger_value or "—",
            response_text=rule.response_text or "—",
            photos_count=photos_count,
            status="فعال 🟢" if rule.enabled else "غیرفعال 🔴",
        )
        keyboard = keyboards.rule_detail_keyboard(rule)

    context.user_data[state.CURRENT_RULE_ID] = rule_id
    state.set_menu(context, state.MENU_RULE_DETAIL)
    await update.effective_message.reply_text(detail, reply_markup=keyboard)


async def handle_rule_detail_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    rule_id = context.user_data.get(state.CURRENT_RULE_ID)
    if rule_id is None:
        return False

    if text == texts.BTN_BACK_TO_RULES:
        await show_rules_menu(update, context)
        return True

    if text == texts.BTN_RULE_TOGGLE:
        with get_session() as session:
            rule = session.get(Rule, rule_id)
            if rule is None or rule.is_system:
                await update.effective_message.reply_text(texts.RULE_CANNOT_DELETE_SYSTEM)
                return True
            rule = toggle_rule(session, rule, not rule.enabled)
            is_enabled = rule.enabled  # قبل از بسته‌شدن session ذخیره می‌شود (رفع DetachedInstanceError)
        await update.effective_message.reply_text(
            texts.RULE_TOGGLED_ON if is_enabled else texts.RULE_TOGGLED_OFF
        )
        await _show_rule_detail(update, context, rule_id)
        return True

    if text == texts.BTN_RULE_DELETE:
        with get_session() as session:
            rule = session.get(Rule, rule_id)
            if rule is None:
                await update.effective_message.reply_text(texts.RULE_NOT_FOUND)
                await show_rules_menu(update, context)
                return True
            ok = delete_rule(session, rule)
        if ok:
            await update.effective_message.reply_text(texts.RULE_DELETED)
        else:
            await update.effective_message.reply_text(texts.RULE_CANNOT_DELETE_SYSTEM)
        await show_rules_menu(update, context)
        return True

    return False


# --- افزودن قانون جدید ---


async def handle_trigger_type_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    draft = context.user_data.get(state.RULE_ADD_DRAFT)
    if draft is None:
        await show_rules_menu(update, context)
        return True

    if text == texts.BTN_CANCEL:
        state.clear_rule_add_draft(context)
        await update.effective_message.reply_text(texts.RULE_ADD_CANCELLED)
        await show_rules_menu(update, context)
        return True

    mapping = {
        texts.BTN_TRIGGER_EXACT: TriggerType.EXACT.value,
        texts.BTN_TRIGGER_CONTAINS: TriggerType.CONTAINS.value,
    }
    trigger_type = mapping.get(text)
    if trigger_type is None:
        return False

    draft["trigger_type"] = trigger_type
    context.user_data[state.RULE_ADD_DRAFT] = draft

    state.set_menu(context, state.MENU_RULE_ADD_TRIGGER_VALUE)
    prompt = (
        texts.RULE_ADD_ASK_TRIGGER_VALUE_EXACT
        if trigger_type == TriggerType.EXACT.value
        else texts.RULE_ADD_ASK_TRIGGER_VALUE_CONTAINS
    )
    await update.effective_message.reply_text(prompt, reply_markup=keyboards.cancel_only_keyboard())
    return True


async def handle_trigger_value_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    draft = context.user_data.get(state.RULE_ADD_DRAFT)
    if draft is None:
        await show_rules_menu(update, context)
        return True

    if text == texts.BTN_CANCEL:
        state.clear_rule_add_draft(context)
        await update.effective_message.reply_text(texts.RULE_ADD_CANCELLED)
        await show_rules_menu(update, context)
        return True

    draft["trigger_value"] = text.strip()
    context.user_data[state.RULE_ADD_DRAFT] = draft
    state.set_menu(context, state.MENU_RULE_ADD_RESPONSE_TEXT)
    await update.effective_message.reply_text(
        texts.RULE_ADD_ASK_RESPONSE_TEXT, reply_markup=keyboards.cancel_only_keyboard()
    )
    return True


async def handle_response_text_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    draft = context.user_data.get(state.RULE_ADD_DRAFT)
    if draft is None:
        await show_rules_menu(update, context)
        return True

    if text == texts.BTN_CANCEL:
        state.clear_rule_add_draft(context)
        await update.effective_message.reply_text(texts.RULE_ADD_CANCELLED)
        await show_rules_menu(update, context)
        return True

    draft["response_text"] = None if text.strip() == "-" else text.strip()
    context.user_data[state.RULE_ADD_DRAFT] = draft

    if not draft.get("requires_pro", True):
        # پلن Free: افزودن عکس مخصوص Pro/Pro Max است — رول همین‌جا بدون رسانه ذخیره می‌شود
        # و اصلاً وارد مرحله‌ی «افزودن عکس» نمی‌شویم (نه فقط بلاک‌کردن، بلکه کلاً نمایش داده نمی‌شود).
        with get_session() as session:
            create_rule(
                session,
                business_account_id=draft["business_account_id"],
                trigger_type=TriggerType(draft["trigger_type"]),
                trigger_value=draft.get("trigger_value"),
                response_text=draft.get("response_text"),
                photo_file_ids=[],
                requires_pro=False,
            )
        state.clear_rule_add_draft(context)
        await update.effective_message.reply_text(texts.RULE_ADD_SAVED_FREE_NO_MEDIA)
        await show_rules_menu(update, context)
        return True

    state.set_menu(context, state.MENU_RULE_ADD_PHOTOS)
    await update.effective_message.reply_text(
        texts.RULE_ADD_ASK_PHOTOS, reply_markup=keyboards.photo_step_keyboard()
    )
    return True


async def handle_photos_menu_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    """دکمه‌های «پایان افزودن عکس» یا «انصراف» در مرحله عکس (خود عکس‌ها با Handler جدا پردازش می‌شوند)."""
    draft = context.user_data.get(state.RULE_ADD_DRAFT)
    if draft is None:
        await show_rules_menu(update, context)
        return True

    if text == texts.BTN_CANCEL:
        state.clear_rule_add_draft(context)
        await update.effective_message.reply_text(texts.RULE_ADD_CANCELLED)
        await show_rules_menu(update, context)
        return True

    if text == texts.BTN_PHOTOS_DONE:
        with get_session() as session:
            create_rule(
                session,
                business_account_id=draft["business_account_id"],
                trigger_type=TriggerType(draft["trigger_type"]),
                trigger_value=draft.get("trigger_value"),
                response_text=draft.get("response_text"),
                photo_file_ids=draft.get("photo_file_ids", []),
                requires_pro=draft.get("requires_pro", True),
            )
        state.clear_rule_add_draft(context)
        await update.effective_message.reply_text(texts.RULE_ADD_SAVED)
        await show_rules_menu(update, context)
        return True

    return False


async def rule_add_photo_router(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """دریافت عکس‌های Rule در مرحله MENU_RULE_ADD_PHOTOS."""
    if state.get_menu(context) != state.MENU_RULE_ADD_PHOTOS:
        return False

    draft = context.user_data.get(state.RULE_ADD_DRAFT)
    if draft is None:
        return False

    photo = update.effective_message.photo
    if not photo:
        return False

    existing = draft.setdefault("photo_file_ids", [])
    # سقف واقعی Telegram Bot API برای sendMediaGroup دقیقاً ۱۰ آیتم است
    # (app/services/media_service.py::TELEGRAM_MEDIA_GROUP_MAX). قبلاً اگر کاربر
    # بیشتر از ۱۰ عکس می‌فرستاد، همه ذخیره می‌شدند ولی موقع ارسال واقعی فقط ۱۰
    # تای اول استفاده می‌شد — بدون هیچ هشداری، یعنی عکس‌های ۱۱ به بعد بی‌صدا گم
    # می‌شدند. حالا همان لحظه‌ی افزودن جلویش گرفته می‌شود.
    if len(existing) >= TELEGRAM_MEDIA_GROUP_MAX:
        await update.effective_message.reply_text(
            texts.RULE_ADD_PHOTO_LIMIT_REACHED, reply_markup=keyboards.photo_step_keyboard()
        )
        return True

    largest = photo[-1]  # بزرگترین سایز موجود
    existing.append(largest.file_id)
    context.user_data[state.RULE_ADD_DRAFT] = draft

    await update.effective_message.reply_text(
        texts.RULE_ADD_PHOTO_RECEIVED.format(count=len(draft["photo_file_ids"])),
        reply_markup=keyboards.photo_step_keyboard(),
    )
    return True
