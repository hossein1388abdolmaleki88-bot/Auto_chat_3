"""
هسته اصلی سیستم: مدیریت اتصال Business و پاسخ‌گویی خودکار به پیام‌های مشتریان.

ساختار طبق بخش ۱۲ Specification:
    Business Owner → Telegram Business Account → Connected Business Bot → Bot من
    → Business Message → Rule Engine → پاسخ از طرف Business Account

نکات پیاده‌سازی:
    - از business_connection_id رسمی Bot API استفاده می‌شود (نه userbot/session string).
    - جلوگیری از Loop (بخش ۲۷): پیام‌هایی که از طرف خود بات (یعنی صاحب کسب‌وکار از طریق
      اپ تلگرامش با استفاده از قابلیت Business Chat پاسخ می‌دهد) در فیلد
      Message.from.is_bot یا برابری chat.id با user_chat_id صاحب اتصال قابل‌تشخیص است؛
      همچنین Deduplication روی telegram_message_id انجام می‌شود.
"""
from __future__ import annotations

import asyncio
import logging

from telegram import Update
from telegram.ext import ContextTypes

from app import keyboards, texts
from app.database import get_session
from app.handlers import state
from app.handlers.admin_handlers import is_admin_user
from app.models import MessageDirection, MessageStatus
from app.repository import (
    business_account_is_pro,
    disconnect_business_account,
    get_business_account_by_connection_id,
    get_or_create_customer_chat,
    get_or_create_user,
    has_disconnected_account,
    is_duplicate_message,
    list_rules,
    log_message,
    to_engine_rules,
    upsert_business_connection,
)
from app.rule_engine import EngineContext, match_rule
from app.services.media_service import send_rule_response

logger = logging.getLogger(__name__)


async def on_business_connection(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """آپدیت business_connection: وقتی کاربری اکانت Business خود را وصل/قطع/تغییر می‌دهد.

    رفتار (غیرفعال‌سازی نرم به‌جای حذف — درخواست ادمین):
      - اتصال فعال (is_enabled=True) → ثبت/به‌روزرسانی اتصال. اگر کاربر قبلاً قطع
        کرده بود و اکانتش در مهلت بازیابی بود، همان اکانت (با قوانین و وضعیت پلن)
        دوباره فعال می‌شود و پیام «خوش برگشتی» می‌گیرد؛ وگرنه اتصال جدید ثبت
        می‌شود. در هر دو حالت منوی اصلی «بدون دکمه‌ی اتصال» نمایش داده می‌شود.
      - قطع دسترسی (is_enabled=False) → غیرفعال‌سازی نرم: اکانت همان لحظه از
        «لیست کاربران» ادمین حذف می‌شود و پاسخ‌گویی متوقف می‌شود، ولی قوانین،
        چت‌های مشتری و وضعیت پلن تا DISCONNECT_GRACE_DAYS (۳۰ روز) حفظ می‌شود.
        کاربر پیام توضیحی می‌گیرد و منوی اصلی «با دکمه‌ی اتصال» می‌بیند تا اگر
        برگشت، همه‌چیز بازیابی شود. بعد از مهلت، job پاک‌سازی اکانت را حذف کامل
        می‌کند.
    """
    bc = update.business_connection
    if bc is None:
        return

    if bc.is_enabled:
        with get_session() as session:
            user = get_or_create_user(
                session,
                telegram_user_id=bc.user.id,
                username=bc.user.username,
                first_name=bc.user.first_name,
                last_name=bc.user.last_name,
            )
            can_reply = True
            if bc.rights is not None:
                can_reply = bool(getattr(bc.rights, "can_reply", True))

            # قبل از upsert: آیا اتصال قبلی این کاربر در حالت قطع است؟ (بازگشت)
            reactivated = has_disconnected_account(session, user.id)
            upsert_business_connection(
                session,
                business_connection_id=bc.id,
                user=user,
                telegram_user_id=bc.user.id,
                is_enabled=True,
                can_reply=can_reply,
            )
        try:
            text = texts.CONNECTION_REACTIVATED if reactivated else texts.CONNECTION_ESTABLISHED
            await context.bot.send_message(chat_id=bc.user_chat_id, text=text)
            state.set_menu(context, state.MENU_MAIN)
            await context.bot.send_message(
                chat_id=bc.user_chat_id,
                text=texts.MAIN_MENU_TITLE,
                reply_markup=keyboards.main_menu_keyboard(
                    has_business_account=True, is_admin=is_admin_user(bc.user.id)
                ),
            )
        except Exception:
            logger.exception("Failed to notify user about business connection status")
        return

    # قطع دسترسی → غیرفعال‌سازی نرم (نه حذف): از لیست ادمین پاک می‌شود ولی داده‌ها
    # تا پایان مهلت بازیابی حفظ می‌شود.
    with get_session() as session:
        removed = disconnect_business_account(session, bc.id)
    if removed:
        logger.info(
            "Business account deactivated (soft) because user disconnected (connection=%s)", bc.id
        )

    try:
        await context.bot.send_message(chat_id=bc.user_chat_id, text=texts.CONNECTION_DISABLED)
        state.set_menu(context, state.MENU_MAIN)
        await context.bot.send_message(
            chat_id=bc.user_chat_id,
            text=texts.MAIN_MENU_TITLE,
            reply_markup=keyboards.main_menu_keyboard(
                has_business_account=False, is_admin=is_admin_user(bc.user.id)
            ),
        )
    except Exception:
        logger.exception("Failed to notify user about business connection status")


async def on_business_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """آپدیت business_message: پیامی که در یک چت مدیریت‌شده توسط Business Connection رد و بدل شده."""
    message = update.business_message
    if message is None:
        return

    business_connection_id = message.business_connection_id
    if not business_connection_id:
        return

    # جلوگیری از Loop: پیام‌هایی که خودِ صاحب کسب‌وکار (نه مشتری) از طریق اپ Business ارسال کرده.
    with get_session() as session:
        account = get_business_account_by_connection_id(session, business_connection_id)
        if account is None or not account.is_enabled:
            return

        owner_telegram_id = account.owner.telegram_user_id
        if message.from_user and message.from_user.id == owner_telegram_id:
            # این پیام را خودِ صاحب کسب‌وکار فرستاده (نه مشتری) → پردازش نشود.
            return
        if message.from_user and message.from_user.is_bot:
            return

        # Deduplication (بخش ۲۷): هر پیام فقط یک‌بار پردازش شود.
        if is_duplicate_message(
            session, account.id, message.message_id, MessageDirection.INCOMING
        ):
            return

        incoming_text = message.text or message.caption or ""

        get_or_create_customer_chat(session, account.id, message.chat.id)

        is_pro = business_account_is_pro(account)
        rules = list_rules(session, account.id, only_enabled=True)
        engine_rules = to_engine_rules(rules)

        ctx = EngineContext(
            is_pro=is_pro,
            incoming_text=incoming_text,
            rules=engine_rules,
        )
        matched = match_rule(ctx)

        log_message(
            session,
            business_account_id=account.id,
            telegram_chat_id=message.chat.id,
            telegram_message_id=message.message_id,
            direction=MessageDirection.INCOMING,
            text=incoming_text,
            matched_rule_id=matched.id if matched else None,
            status=MessageStatus.SUCCESS if matched else MessageStatus.IGNORED,
        )

        if matched is None:
            return

        chat_id = message.chat.id
        account_id = account.id  # قبل از بسته شدن session ذخیره می‌شود (رفع DetachedInstanceError)

    # ارسال پاسخ خارج از session (برای جلوگیری از نگه‌داشتن Connection حین I/O شبکه).
    #
    # نکته مهم (رفع یک باگ واقعی قابلیت‌اطمینان): خطاهای شبکه‌ای گذرا (مثلاً
    # httpx.ReadError/NetworkError — دقیقاً چیزی که در محیط واقعی این پروژه هم رخ
    # داده) قبلاً بدون هیچ تلاش مجددی مستقیم FAILED لاگ می‌شدند و مشتری برای همیشه
    # بدون پاسخ می‌ماند، چون این‌جور خطاها معمولاً لحظه‌ای هستند و چند صدم ثانیه بعد
    # برطرف می‌شوند. حالا حداکثر ۳ بار (با کمی مکث افزایشی بین هر تلاش) امتحان می‌شود.
    sent_message_id: int | None = None
    status = MessageStatus.FAILED
    max_attempts = 3
    for attempt in range(1, max_attempts + 1):
        try:
            sent_message_id = await send_rule_response(
                context=context,
                business_connection_id=business_connection_id,
                chat_id=chat_id,
                rule=matched,
            )
            status = MessageStatus.SUCCESS
            break
        except Exception:
            if attempt == max_attempts:
                logger.exception(
                    "Failed to send rule response after %d attempts (business_account_id=%s, chat_id=%s)",
                    max_attempts,
                    account_id,
                    chat_id,
                )
            else:
                logger.warning(
                    "Send attempt %d/%d failed, retrying...", attempt, max_attempts
                )
                await asyncio.sleep(attempt * 0.75)

    with get_session() as session:
        log_message(
            session,
            business_account_id=account_id,
            telegram_chat_id=chat_id,
            # اگر ارسال ناموفق بود (sent_message_id=None) از incoming message_id به‌عنوان
            # کلید یکتای موقت استفاده می‌شود تا Dedup به‌هم نریزد؛ در حالت موفق، شناسه
            # واقعی پیام خروجی ثبت می‌شود.
            telegram_message_id=sent_message_id or message.message_id,
            direction=MessageDirection.OUTGOING,
            text=matched.response_text,
            matched_rule_id=matched.id,
            status=status,
        )
