"""پنل مدیریت — کاملاً دکمه‌ای با Reply Keyboard، فقط برای ADMIN_TELEGRAM_IDS."""
from __future__ import annotations

import asyncio
import logging
import re

from telegram import Bot, Update
from telegram.error import RetryAfter
from telegram.ext import ContextTypes

from app import keyboards, texts
from app.config import PROJECT_ROOT, settings
from app.database import get_session
from app.handlers import state
from app.models import BusinessAccount, PlanType
from app.timeutil import days_left_until, fa_digits, format_iran
from app.repository import (
    activate_pro,
    add_force_join_channel,
    cancel_pro,
    count_business_accounts,
    delete_business_account,
    get_admin_username,
    get_free_rule_limit,
    get_pricing_option,
    get_pro_duration_days,
    get_pro_price,
    get_pro_rule_limit,
    get_stats,
    is_force_join_enabled,
    list_all_business_accounts_full,
    list_all_user_telegram_ids,
    list_force_join_channels,
    list_pricing_options,
    remove_force_join_channel,
    reset_help_text_template,
    set_admin_username,
    set_force_join_enabled,
    set_free_rule_limit,
    set_help_text_template,
    set_pricing_price,
    set_pro_duration_days,
    set_pro_price,
    set_pro_rule_limit,
)

logger = logging.getLogger(__name__)

# فایل‌هایی که برای جابه‌جایی کامل بات به یک سرور دیگر لازم است — همه در ریشه‌ی
# پروژه (کنار پوشه‌ی app/) قرار دارند؛ به app/config.py (PROJECT_ROOT) مراجعه کنید.
BACKUP_FILES = [
    (PROJECT_ROOT / "app.db", "app.db", "ADMIN_BACKUP_CAPTION_DB"),
    (PROJECT_ROOT / "bot_persistence.pickle", "bot_persistence.pickle", "ADMIN_BACKUP_CAPTION_PICKLE"),
    (PROJECT_ROOT / ".env", ".env", "ADMIN_BACKUP_CAPTION_ENV"),
]


async def send_backup_files(bot: Bot, chat_id: int, *, auto: bool = False) -> None:
    """سه فایل لازم برای جابه‌جایی سرور (app.db، bot_persistence.pickle، .env) را
    به‌صورت پیوست مستقیماً در همین چت تلگرام ارسال می‌کند — هم از دکمه‌ی دستی
    «💾 دریافت بکاپ» در پنل ادمین، هم از Job خودکار روزانه (app/bot.py) صدا زده
    می‌شود. اگر فایلی هنوز ساخته نشده باشد (مثلاً bot_persistence.pickle در
    اولین اجرا)، به‌جای کرش کردن، فقط با یک پیام هشدار رد می‌شود."""
    if not auto:
        await bot.send_message(chat_id=chat_id, text=texts.ADMIN_BACKUP_SENDING)

    sent_any = False
    for path, filename, caption_key in BACKUP_FILES:
        if not path.exists():
            await bot.send_message(chat_id=chat_id, text=texts.ADMIN_BACKUP_MISSING_FILE.format(filename=filename))
            continue
        caption = getattr(texts, caption_key)
        # تلاش مجدد در خطای شبکه‌ای گذرا (دقیقاً همان ReadTimeout که در محیط واقعی
        # این پروژه هنگام ارسال یک فایل بزرگ‌تر روی اینترنت ناپایدار رخ داد).
        sent = False
        for attempt in range(1, 4):
            try:
                with open(path, "rb") as f:
                    await bot.send_document(chat_id=chat_id, document=f, filename=filename, caption=caption)
                sent = True
                break
            except Exception:
                if attempt == 3:
                    logger.exception(
                        "Failed to send backup file %s to chat_id=%s after 3 attempts", filename, chat_id
                    )
                else:
                    await asyncio.sleep(attempt * 1.5)
        if sent:
            sent_any = True

    if not sent_any:
        return
    if auto:
        await bot.send_message(chat_id=chat_id, text=texts.ADMIN_BACKUP_AUTO_CAPTION)
    else:
        await bot.send_message(chat_id=chat_id, text=texts.ADMIN_BACKUP_DONE)


def is_admin_user(telegram_user_id: int) -> bool:
    return telegram_user_id in settings.admin_telegram_ids


async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    tg_user = update.effective_user
    if not is_admin_user(tg_user.id):
        await update.effective_message.reply_text(texts.NOT_ADMIN_NO_PANEL_HINT)
        return
    await show_admin_panel(update, context)


async def show_admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    state.set_menu(context, state.MENU_ADMIN)
    await update.effective_message.reply_text(
        texts.ADMIN_PANEL_TITLE, reply_markup=keyboards.admin_panel_keyboard()
    )


async def handle_admin_menu_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    if text == texts.BTN_ADMIN_USERS:
        await _send_users_text_list(update, context)
        await _show_users_page(update, context)
        return True
    if text == texts.BTN_ADMIN_PRICE:
        await _show_price_menu(update, context)
        return True
    if text == texts.BTN_ADMIN_RULE_LIMITS:
        await _show_rule_limits_menu(update, context)
        return True
    if text == texts.BTN_ADMIN_BROADCAST:
        await _show_broadcast_compose(update, context)
        return True
    if text == texts.BTN_ADMIN_BACKUP_NOW:
        await send_backup_files(context.bot, update.effective_chat.id)
        return True
    if text == texts.BTN_ADMIN_CONTENT:
        await _show_content_menu(update, context)
        return True
    if text == texts.BTN_ADMIN_FORCE_JOIN:
        await _show_force_join_menu(update, context)
        return True
    if text == texts.BTN_ADMIN_STATS:
        await _show_stats(update, context)
        return True
    return False


# --- کاربران ---


async def _send_users_text_list(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """لیست کامل کاربران را به‌صورت یک یا چند پیام متنی (نه دکمه‌ای) ارسال می‌کند.
    اگر تعداد کاربران زیاد باشد و طول متن از سقف تلگرام (۴۰۹۶ کاراکتر) رد شود،
    به چند پیام متوالی تقسیم می‌شود."""
    with get_session() as session:
        accounts = list_all_business_accounts_full(session)
        icons = {"FREE": "🆓", "PRO": "⭐", "PRO_MAX": "🚀"}
        lines = []
        for acc in accounts:
            owner = acc.owner
            handle = f" (@{owner.username})" if owner.username else ""
            lines.append(
                texts.ADMIN_USERS_LIST_LINE.format(
                    icon=icons.get(acc.plan.value, "🆓"),
                    account_id=acc.id,
                    name=owner.first_name or "-",
                    handle=handle,
                    plan=acc.plan.value,
                    telegram_id=owner.telegram_user_id,
                )
            )

    if not lines:
        await update.effective_message.reply_text(texts.ADMIN_NO_USERS)
        return

    header = texts.ADMIN_USERS_LIST_TITLE.format(count=len(lines))
    chunks: list[str] = []
    current = header
    for line in lines:
        # ۳۵۰۰ به‌جای ۴۰۹۶ برای حاشیه‌ی امن (سقف واقعی تلگرام برای پیام متنی).
        if len(current) + len(line) + 2 > 3500:
            chunks.append(current)
            current = ""
        current += ("\n\n" if current else "") + line
    if current:
        chunks.append(current)

    for chunk in chunks:
        await update.effective_message.reply_text(chunk)


async def _show_users_page(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """پس از ارسال لیست متنی کامل (_send_users_text_list)، دیگر نیازی به کیبورد
    دکمه‌ای/صفحه‌بندی نیست: فقط از ادمین می‌خواهیم عدد ID کاربر مدنظرش را تایپ کند."""
    with get_session() as session:
        has_any = count_business_accounts(session) > 0

    state.set_menu(context, state.MENU_ADMIN_USERS)
    if not has_any:
        await update.effective_message.reply_text(
            texts.ADMIN_NO_USERS, reply_markup=keyboards.admin_back_keyboard()
        )
        return
    await update.effective_message.reply_text(
        texts.ADMIN_USERS_TYPE_ID_PROMPT, reply_markup=keyboards.admin_back_keyboard()
    )


async def handle_admin_users_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    if text == texts.BTN_ADMIN_BACK:
        await show_admin_panel(update, context)
        return True

    # ادمین باید عدد ID کاربر (همان چیزی که در لیست متنی به‌صورت #7 و... نمایش
    # داده شد) را تایپ کند تا وارد صفحه‌ی مدیریت کامل دسترسی همان کاربر شود.
    cleaned = text.strip().lstrip("#")
    if not cleaned.isdigit():
        await update.effective_message.reply_text(
            texts.ADMIN_INVALID_USER_ID, reply_markup=keyboards.admin_back_keyboard()
        )
        return True

    account_id = int(cleaned)
    with get_session() as session:
        exists = session.get(BusinessAccount, account_id) is not None
    if not exists:
        await update.effective_message.reply_text(
            texts.ADMIN_INVALID_USER_ID, reply_markup=keyboards.admin_back_keyboard()
        )
        return True

    context.user_data[state.ADMIN_SELECTED_ACCOUNT_ID] = account_id
    await _show_user_detail(update, context, account_id)
    return True


async def _show_user_detail(update: Update, context: ContextTypes.DEFAULT_TYPE, account_id: int) -> None:
    with get_session() as session:
        account = session.get(BusinessAccount, account_id)
        if account is None:
            await update.effective_message.reply_text(
                texts.RULE_NOT_FOUND, reply_markup=keyboards.admin_back_keyboard()
            )
            return

        owner = account.owner
        connection_status = "متصل ✅" if account.is_enabled else "قطع ❌"
        is_pro_plan = account.plan.value in ("PRO", "PRO_MAX")
        remaining_days = (
            f"{fa_digits(days_left_until(account.pro_until))} روز" if is_pro_plan else "-"
        )
        detail = texts.ADMIN_USER_DETAIL.format(
            telegram_id=owner.telegram_user_id,
            username=("@" + owner.username) if owner.username else "-",
            first_name=owner.first_name or "-",
            plan=account.plan.value,
            pro_until=format_iran(account.pro_until),
            remaining_days=remaining_days,
            status=connection_status,
            created_at=format_iran(account.created_at, fmt="%Y/%m/%d"),
        )
        keyboard = keyboards.admin_user_detail_keyboard(account)

    context.user_data[state.ADMIN_SELECTED_ACCOUNT_ID] = account_id
    state.set_menu(context, state.MENU_ADMIN_USER_DETAIL)
    await update.effective_message.reply_text(detail, reply_markup=keyboard)


async def handle_admin_user_detail_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    account_id = context.user_data.get(state.ADMIN_SELECTED_ACCOUNT_ID)
    if account_id is None:
        return False

    if text == texts.BTN_ADMIN_BACK:
        await _show_users_page(update, context)
        return True

    if text in (texts.BTN_ADMIN_ACTIVATE_PRO, texts.BTN_ADMIN_RENEW_PRO):
        state.set_menu(context, state.MENU_ADMIN_ACTIVATE_PLAN_CHOICE)
        await update.effective_message.reply_text(
            texts.ADMIN_ACTIVATE_ASK_PLAN, reply_markup=keyboards.admin_activate_plan_choice_keyboard()
        )
        return True

    if text == texts.BTN_ADMIN_CANCEL_PRO:
        with get_session() as session:
            account = session.get(BusinessAccount, account_id)
            if account is None:
                return True
            cancel_pro(session, account)
        await update.effective_message.reply_text(texts.ADMIN_PRO_CANCELLED)
        await _show_user_detail(update, context, account_id)
        return True

    if text == texts.BTN_ADMIN_DELETE_USER:
        with get_session() as session:
            account = session.get(BusinessAccount, account_id)
            if account is None:
                return True
            name = account.owner.first_name or "-"
            is_enabled = account.is_enabled

        connection_warning = (
            texts.ADMIN_USER_DELETE_CONNECTION_WARNING if is_enabled else ""
        )
        confirm_text = texts.ADMIN_USER_DELETE_CONFIRM.format(
            account_id=account_id,
            name=name,
            connection_warning=connection_warning,
        )
        state.set_menu(context, state.MENU_ADMIN_USER_DELETE_CONFIRM)
        await update.effective_message.reply_text(
            confirm_text, reply_markup=keyboards.admin_user_delete_confirm_keyboard()
        )
        return True

    return False


async def handle_admin_user_delete_confirm_text(
    update: Update, context: ContextTypes.DEFAULT_TYPE, text: str
) -> bool:
    account_id = context.user_data.get(state.ADMIN_SELECTED_ACCOUNT_ID)
    if account_id is None:
        return False

    if text == texts.BTN_ADMIN_BACK:
        await _show_user_detail(update, context, account_id)
        return True

    if text == texts.BTN_ADMIN_DELETE_USER_CONFIRM:
        with get_session() as session:
            ok = delete_business_account(session, account_id)
        context.user_data.pop(state.ADMIN_SELECTED_ACCOUNT_ID, None)
        if ok:
            await update.effective_message.reply_text(
                texts.ADMIN_USER_DELETED.format(account_id=account_id)
            )
        else:
            await update.effective_message.reply_text(texts.ADMIN_INVALID_USER_ID)
        # ارسال لیست به‌روزشده‌ی کاربران + درخواست انتخاب دوباره
        await _send_users_text_list(update, context)
        await _show_users_page(update, context)
        return True

    return False


async def handle_admin_activate_plan_choice_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    account_id = context.user_data.get(state.ADMIN_SELECTED_ACCOUNT_ID)
    if account_id is None:
        return False

    if text == texts.BTN_ADMIN_BACK:
        await _show_user_detail(update, context, account_id)
        return True

    mapping = {texts.BTN_PLAN_PRO: PlanType.PRO, texts.BTN_PLAN_PRO_MAX: PlanType.PRO_MAX}
    plan = mapping.get(text)
    if plan is None:
        return False

    with get_session() as session:
        options = list_pricing_options(session, plan=plan, only_enabled=True)
        if not options:
            await update.effective_message.reply_text(
                texts.ADMIN_ACTIVATE_NO_OPTIONS, reply_markup=keyboards.admin_activate_plan_choice_keyboard()
            )
            return True

        context.user_data[state.ADMIN_ACTIVATE_PLAN] = plan.value
        state.set_menu(context, state.MENU_ADMIN_ACTIVATE_DURATION_CHOICE)
        plan_name = "Pro Max" if plan == PlanType.PRO_MAX else "Pro"
        await update.effective_message.reply_text(
            texts.ADMIN_ACTIVATE_ASK_DURATION.format(plan=plan_name),
            reply_markup=keyboards.admin_activate_duration_keyboard(options),
        )
    return True


async def handle_admin_activate_duration_choice_text(
    update: Update, context: ContextTypes.DEFAULT_TYPE, text: str
) -> bool:
    account_id = context.user_data.get(state.ADMIN_SELECTED_ACCOUNT_ID)
    if account_id is None:
        return False

    if text == texts.BTN_ADMIN_BACK:
        state.set_menu(context, state.MENU_ADMIN_ACTIVATE_PLAN_CHOICE)
        await update.effective_message.reply_text(
            texts.ADMIN_ACTIVATE_ASK_PLAN, reply_markup=keyboards.admin_activate_plan_choice_keyboard()
        )
        return True

    pricing_id = keyboards.extract_id(text)
    if pricing_id is None:
        return False

    plan_value = context.user_data.get(state.ADMIN_ACTIVATE_PLAN, PlanType.PRO.value)
    plan = PlanType(plan_value)
    with get_session() as session:
        option = get_pricing_option(session, pricing_id)
        if option is None:
            return False
        account = session.get(BusinessAccount, account_id)
        if account is None:
            return True
        account = activate_pro(session, account, plan=plan, duration_days=option.duration_days)
        until_str = format_iran(account.pro_until)

    plan_name = "Pro Max" if plan == PlanType.PRO_MAX else "Pro"
    await update.effective_message.reply_text(texts.ADMIN_PRO_ACTIVATED.format(plan=plan_name, until=until_str))
    await _show_user_detail(update, context, account_id)
    return True


# --- قیمت / مدت Pro ---


async def _show_price_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    with get_session() as session:
        price = get_pro_price(session)
        duration = get_pro_duration_days(session)

    text = texts.ADMIN_PRICE_CURRENT.format(price=price, duration=duration)
    state.set_menu(context, state.MENU_ADMIN_PRICE)
    await update.effective_message.reply_text(text, reply_markup=keyboards.admin_price_menu_keyboard())


async def handle_admin_price_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    if text == texts.BTN_ADMIN_BACK:
        await show_admin_panel(update, context)
        return True
    if text == texts.BTN_ADMIN_MANAGE_PRICING:
        await _show_pricing_list(update, context)
        return True
    if text == texts.BTN_ADMIN_EDIT_PRICE:
        state.set_menu(context, state.MENU_ADMIN_EDIT_PRICE)
        await update.effective_message.reply_text(
            texts.ADMIN_PRICE_ASK_NEW, reply_markup=keyboards.admin_back_keyboard()
        )
        return True
    if text == texts.BTN_ADMIN_EDIT_DURATION:
        state.set_menu(context, state.MENU_ADMIN_EDIT_DURATION)
        await update.effective_message.reply_text(
            texts.ADMIN_DURATION_ASK_NEW, reply_markup=keyboards.admin_back_keyboard()
        )
        return True
    return False


async def handle_admin_edit_price_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    if text == texts.BTN_ADMIN_BACK:
        await _show_price_menu(update, context)
        return True
    if not text.isdigit():
        await update.effective_message.reply_text(texts.ADMIN_INVALID_NUMBER)
        return True
    with get_session() as session:
        set_pro_price(session, int(text))
    await update.effective_message.reply_text(texts.ADMIN_PRICE_UPDATED.format(price=int(text)))
    await _show_price_menu(update, context)
    return True


async def handle_admin_edit_duration_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    if text == texts.BTN_ADMIN_BACK:
        await _show_price_menu(update, context)
        return True
    if not text.isdigit():
        await update.effective_message.reply_text(texts.ADMIN_INVALID_NUMBER)
        return True
    with get_session() as session:
        set_pro_duration_days(session, int(text))
    await update.effective_message.reply_text(texts.ADMIN_DURATION_UPDATED.format(duration=int(text)))
    await _show_price_menu(update, context)
    return True


# --- سقف تعداد قانون اختصاصی هر پلن (بخش مجزا و مستقل در پنل ادمین) ---


async def _show_rule_limits_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    with get_session() as session:
        free_limit = get_free_rule_limit(session)
        pro_limit = get_pro_rule_limit(session)

    text = texts.RULE_LIMITS_HEADER.format(free_limit=free_limit, pro_limit=pro_limit)
    state.set_menu(context, state.MENU_ADMIN_RULE_LIMITS)
    await update.effective_message.reply_text(text, reply_markup=keyboards.admin_rule_limits_keyboard())


async def handle_admin_rule_limits_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    if text == texts.BTN_ADMIN_BACK:
        await show_admin_panel(update, context)
        return True
    if text == texts.BTN_ADMIN_EDIT_RULE_LIMIT:
        state.set_menu(context, state.MENU_ADMIN_EDIT_RULE_LIMIT)
        await update.effective_message.reply_text(
            texts.ADMIN_RULE_LIMIT_ASK_NEW, reply_markup=keyboards.admin_back_keyboard()
        )
        return True
    if text == texts.BTN_ADMIN_EDIT_PRO_RULE_LIMIT:
        state.set_menu(context, state.MENU_ADMIN_EDIT_PRO_RULE_LIMIT)
        await update.effective_message.reply_text(
            texts.ADMIN_PRO_RULE_LIMIT_ASK_NEW, reply_markup=keyboards.admin_back_keyboard()
        )
        return True
    return False


async def handle_admin_edit_rule_limit_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    if text == texts.BTN_ADMIN_BACK:
        await _show_rule_limits_menu(update, context)
        return True
    if not text.isdigit():
        await update.effective_message.reply_text(texts.ADMIN_INVALID_NUMBER)
        return True
    with get_session() as session:
        set_free_rule_limit(session, int(text))
    await update.effective_message.reply_text(texts.ADMIN_RULE_LIMIT_UPDATED.format(limit=int(text)))
    await _show_rule_limits_menu(update, context)
    return True


async def handle_admin_edit_pro_rule_limit_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    if text == texts.BTN_ADMIN_BACK:
        await _show_rule_limits_menu(update, context)
        return True
    if not text.isdigit():
        await update.effective_message.reply_text(texts.ADMIN_INVALID_NUMBER)
        return True
    with get_session() as session:
        set_pro_rule_limit(session, int(text))
    await update.effective_message.reply_text(texts.ADMIN_PRO_RULE_LIMIT_UPDATED.format(limit=int(text)))
    await _show_rule_limits_menu(update, context)
    return True


# --- محتوا و متن‌ها (یوزرنیم پاسخ‌گوی خرید + متن راهنما) ---


async def _show_content_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    with get_session() as session:
        admin_username = get_admin_username(session)

    state.set_menu(context, state.MENU_ADMIN_CONTENT)
    if admin_username:
        text = texts.ADMIN_CONTENT_HEADER.format(admin_username=admin_username)
    else:
        text = texts.ADMIN_CONTENT_NO_USERNAME_NOTE
    await update.effective_message.reply_text(text, reply_markup=keyboards.admin_content_keyboard())


async def handle_admin_content_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    if text == texts.BTN_ADMIN_BACK:
        await show_admin_panel(update, context)
        return True
    if text == texts.BTN_ADMIN_EDIT_SUPPORT_USERNAME:
        state.set_menu(context, state.MENU_ADMIN_EDIT_SUPPORT_USERNAME)
        await update.effective_message.reply_text(
            texts.ADMIN_EDIT_SUPPORT_USERNAME_ASK, reply_markup=keyboards.admin_back_keyboard()
        )
        return True
    if text == texts.BTN_ADMIN_EDIT_HELP_TEXT:
        state.set_menu(context, state.MENU_ADMIN_EDIT_HELP_TEXT)
        await update.effective_message.reply_text(
            texts.ADMIN_EDIT_HELP_TEXT_ASK, reply_markup=keyboards.admin_edit_help_text_keyboard()
        )
        return True
    return False


async def handle_admin_edit_support_username_text(
    update: Update, context: ContextTypes.DEFAULT_TYPE, text: str
) -> bool:
    if text == texts.BTN_ADMIN_BACK:
        await _show_content_menu(update, context)
        return True

    cleaned = text.strip().lstrip("@")
    # یوزرنیم تلگرام طبق قوانین خودِ تلگرام: ۵ تا ۳۲ کاراکتر، فقط حروف انگلیسی/عدد/
    # آندرلاین، و باید با یک حرف شروع شود.
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{4,31}", cleaned):
        await update.effective_message.reply_text(
            texts.ADMIN_EDIT_SUPPORT_USERNAME_INVALID, reply_markup=keyboards.admin_back_keyboard()
        )
        return True

    with get_session() as session:
        set_admin_username(session, cleaned)
    await update.effective_message.reply_text(texts.ADMIN_EDIT_SUPPORT_USERNAME_UPDATED.format(username=cleaned))
    await _show_content_menu(update, context)
    return True


async def handle_admin_edit_help_text_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    if text == texts.BTN_ADMIN_BACK:
        await _show_content_menu(update, context)
        return True
    if text == texts.BTN_ADMIN_RESET_HELP_TEXT:
        with get_session() as session:
            reset_help_text_template(session)
        await update.effective_message.reply_text(texts.ADMIN_EDIT_HELP_TEXT_RESET)
        await _show_content_menu(update, context)
        return True

    with get_session() as session:
        set_help_text_template(session, text)
    await update.effective_message.reply_text(texts.ADMIN_EDIT_HELP_TEXT_UPDATED)
    await _show_content_menu(update, context)
    return True


# --- پیام همگانی (Broadcast) ---


async def _show_broadcast_compose(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    context.user_data.pop(state.ADMIN_BROADCAST_DRAFT, None)
    state.set_menu(context, state.MENU_ADMIN_BROADCAST_COMPOSE)
    await update.effective_message.reply_text(
        texts.ADMIN_BROADCAST_ASK_TEXT, reply_markup=keyboards.admin_back_keyboard()
    )


async def handle_admin_broadcast_compose_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    if text == texts.BTN_ADMIN_BACK:
        await show_admin_panel(update, context)
        return True

    with get_session() as session:
        user_ids = list_all_user_telegram_ids(session)

    if not user_ids:
        await update.effective_message.reply_text(texts.ADMIN_BROADCAST_NO_USERS)
        await show_admin_panel(update, context)
        return True

    context.user_data[state.ADMIN_BROADCAST_DRAFT] = {"text": text, "user_ids": user_ids}
    state.set_menu(context, state.MENU_ADMIN_BROADCAST_CONFIRM)
    await update.effective_message.reply_text(
        texts.ADMIN_BROADCAST_PREVIEW.format(text=text, count=len(user_ids)),
        reply_markup=keyboards.admin_broadcast_confirm_keyboard(),
    )
    return True


async def handle_admin_broadcast_confirm_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    draft = context.user_data.get(state.ADMIN_BROADCAST_DRAFT)

    if text == texts.BTN_ADMIN_BROADCAST_CANCEL or text == texts.BTN_ADMIN_BACK:
        context.user_data.pop(state.ADMIN_BROADCAST_DRAFT, None)
        await update.effective_message.reply_text(texts.ADMIN_BROADCAST_CANCELLED)
        await show_admin_panel(update, context)
        return True

    if text != texts.BTN_ADMIN_BROADCAST_SEND:
        return False

    if draft is None:
        await show_admin_panel(update, context)
        return True

    broadcast_text = draft["text"]
    user_ids = draft["user_ids"]
    context.user_data.pop(state.ADMIN_BROADCAST_DRAFT, None)

    await update.effective_message.reply_text(texts.ADMIN_BROADCAST_SENDING.format(count=len(user_ids)))

    # نکته مهم (رفع یک ضعف قابلیت‌اطمینان): تلگرام سقف نرخ ارسال دارد (تقریباً ۳۰
    # پیام در ثانیه در کل حساب بات). قبلاً اگر تعداد کاربران زیاد بود و به این سقف
    # می‌خوردیم، خطای RetryAfter مثل هر خطای دیگری فوراً «ناموفق» ثبت می‌شد — در
    # حالی که با یک صبر کوتاه (دقیقاً همان مدتی که خودِ تلگرام در پیام خطا می‌گوید)
    # واقعاً قابل ارسال بود. حالا: (۱) بین هر ارسال یک مکث خیلی کوچک برای پیشگیری
    # از رسیدن به سقف، (۲) در صورت RetryAfter، یک‌بار صبر و تلاش مجدد.
    success = 0
    failed = 0
    for uid in user_ids:
        for attempt in range(2):
            try:
                await context.bot.send_message(chat_id=uid, text=broadcast_text)
                success += 1
                break
            except RetryAfter as e:
                if attempt == 0:
                    await asyncio.sleep(e.retry_after + 0.5)
                    continue
                failed += 1
                logger.info("Broadcast rate-limited twice for telegram_user_id=%s, giving up", uid)
            except Exception:
                failed += 1
                logger.info("Broadcast failed for telegram_user_id=%s (likely blocked the bot)", uid)
                break
        await asyncio.sleep(0.05)

    await update.effective_message.reply_text(
        texts.ADMIN_BROADCAST_DONE.format(success=success, failed=failed)
    )
    await show_admin_panel(update, context)
    return True


# --- مدیریت قیمت‌های خرید (pricing_plans: Pro/Pro Max × مدت) ---


async def _show_pricing_list(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    with get_session() as session:
        options = list_pricing_options(session)
        # تبدیل صریح به مقادیر ساده همین‌جا، داخل session — نه بعداً. این‌طوری کیبورد
        # به هیچ آبجکت ORM (و در نتیجه به عمر session) وابسته نیست.
        plain_options = [(opt.id, opt.plan.value, opt.duration_days, opt.price) for opt in options]
        keyboard = keyboards.admin_pricing_list_keyboard(plain_options)
    state.set_menu(context, state.MENU_ADMIN_PRICING_LIST)
    await update.effective_message.reply_text(texts.ADMIN_PRICING_HEADER, reply_markup=keyboard)


async def handle_admin_pricing_list_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    if text == texts.BTN_ADMIN_BACK:
        await _show_price_menu(update, context)
        return True

    pricing_id = keyboards.extract_id(text)
    if pricing_id is None:
        return False

    with get_session() as session:
        option = get_pricing_option(session, pricing_id)
        if option is None:
            await _show_pricing_list(update, context)
            return True
        plan_name = "Pro Max" if option.plan == PlanType.PRO_MAX else "Pro"
        duration_days = option.duration_days

    context.user_data[state.ADMIN_SELECTED_PRICING_ID] = pricing_id
    state.set_menu(context, state.MENU_ADMIN_PRICING_EDIT)
    await update.effective_message.reply_text(
        texts.ADMIN_PRICING_ASK_NEW_PRICE.format(plan=plan_name, duration=duration_days),
        reply_markup=keyboards.admin_back_keyboard(),
    )
    return True


async def handle_admin_pricing_edit_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    if text == texts.BTN_ADMIN_BACK:
        await _show_pricing_list(update, context)
        return True
    if not text.isdigit():
        await update.effective_message.reply_text(texts.ADMIN_INVALID_NUMBER)
        return True

    pricing_id = context.user_data.get(state.ADMIN_SELECTED_PRICING_ID)
    if pricing_id is None:
        await _show_pricing_list(update, context)
        return True

    with get_session() as session:
        option = set_pricing_price(session, pricing_id, int(text))
        if option is None:
            await _show_pricing_list(update, context)
            return True
        plan_name = "Pro Max" if option.plan == PlanType.PRO_MAX else "Pro"
        duration_days = option.duration_days

    await update.effective_message.reply_text(
        texts.ADMIN_PRICING_UPDATED.format(plan=plan_name, duration=duration_days, price=int(text))
    )
    await _show_pricing_list(update, context)
    return True


# --- عضویت اجباری ---


async def _show_force_join_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    with get_session() as session:
        enabled = is_force_join_enabled(session)

    status = "فعال ✅" if enabled else "غیرفعال ❌"
    text = texts.ADMIN_FORCE_JOIN_HEADER.format(status=status)
    state.set_menu(context, state.MENU_ADMIN_FORCE_JOIN)
    await update.effective_message.reply_text(text, reply_markup=keyboards.admin_force_join_keyboard(enabled))


async def handle_admin_force_join_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    if text == texts.BTN_ADMIN_BACK:
        await show_admin_panel(update, context)
        return True

    if text in (texts.BTN_ADMIN_FJ_TOGGLE_ON, texts.BTN_ADMIN_FJ_TOGGLE_OFF):
        with get_session() as session:
            enabled = is_force_join_enabled(session)
            set_force_join_enabled(session, not enabled)
        await _show_force_join_menu(update, context)
        return True

    if text == texts.BTN_ADMIN_FJ_ADD_CHANNEL:
        state.set_menu(context, state.MENU_ADMIN_FJ_ADD_CHANNEL)
        await update.effective_message.reply_text(
            texts.ADMIN_FORCE_JOIN_ASK_CHANNEL, reply_markup=keyboards.admin_back_keyboard()
        )
        return True

    if text == texts.BTN_ADMIN_FJ_LIST_CHANNELS:
        await _show_force_join_channels(update, context)
        return True

    return False


async def _show_force_join_channels(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    with get_session() as session:
        channels = list_force_join_channels(session)
        if not channels:
            await update.effective_message.reply_text(
                texts.ADMIN_FORCE_JOIN_NO_CHANNELS, reply_markup=keyboards.admin_back_keyboard()
            )
            state.set_menu(context, state.MENU_ADMIN_FORCE_JOIN)
            return
        keyboard = keyboards.admin_force_join_channels_keyboard(channels)

    state.set_menu(context, state.MENU_ADMIN_FORCE_JOIN_LIST)
    await update.effective_message.reply_text(texts.ADMIN_FORCE_JOIN_PICK_TO_REMOVE, reply_markup=keyboard)


async def handle_admin_force_join_list_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    if text == texts.BTN_ADMIN_BACK:
        await _show_force_join_menu(update, context)
        return True

    channel_id = keyboards.extract_id(text)
    if channel_id is not None:
        with get_session() as session:
            remove_force_join_channel(session, channel_id)
        await update.effective_message.reply_text(texts.ADMIN_FORCE_JOIN_CHANNEL_REMOVED)
        await _show_force_join_channels(update, context)
        return True

    return False


async def handle_admin_fj_add_channel_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    if text == texts.BTN_ADMIN_BACK:
        await _show_force_join_menu(update, context)
        return True
    if not text.strip():
        return True
    with get_session() as session:
        add_force_join_channel(session, channel_id=text.strip())
    await update.effective_message.reply_text(texts.ADMIN_FORCE_JOIN_CHANNEL_ADDED)
    await _show_force_join_menu(update, context)
    return True


# --- آمار ---


async def _show_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    with get_session() as session:
        stats = get_stats(session)

    text = texts.ADMIN_STATS_TEMPLATE.format(**stats)
    state.set_menu(context, state.MENU_ADMIN)
    await update.effective_message.reply_text(text, reply_markup=keyboards.admin_panel_keyboard())
