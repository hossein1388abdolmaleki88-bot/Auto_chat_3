"""Handlerهای منوی اصلی کاربر عادی (صاحب کسب‌وکار) — با Reply Keyboard دائمی."""
from __future__ import annotations

from telegram import Update
from telegram.ext import ContextTypes

from app import keyboards, texts
from app.config import settings
from app.database import get_session
from app.handlers import state
from app.handlers.force_join import ensure_membership_or_prompt
from app.models import PlanType
from app.timeutil import days_left_until, fa_digits, format_iran
from app.repository import (
    business_account_is_pro,
    get_admin_username,
    get_business_accounts_for_user,
    get_free_rule_limit,
    get_help_text_template,
    get_or_create_user,
    get_pricing_option,
    get_pro_rule_limit,
    get_rule_limit_for_account,
    list_pricing_options,
)


def is_admin_user(telegram_user_id: int) -> bool:
    return telegram_user_id in settings.admin_telegram_ids


async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    tg_user = update.effective_user
    with get_session() as session:
        get_or_create_user(
            session,
            telegram_user_id=tg_user.id,
            username=tg_user.username,
            first_name=tg_user.first_name,
            last_name=tg_user.last_name,
        )

    if not await ensure_membership_or_prompt(update, context):
        return

    context.user_data.clear()
    await update.effective_message.reply_text(
        texts.WELCOME.format(name=tg_user.first_name or "دوست عزیز")
    )
    await show_main_menu(update, context)


async def show_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    tg_user = update.effective_user
    with get_session() as session:
        user = get_or_create_user(session, telegram_user_id=tg_user.id)
        accounts = get_business_accounts_for_user(session, user.id)
        has_business_account = bool(accounts)

    state.set_menu(context, state.MENU_MAIN)
    state.clear_rule_add_draft(context)
    keyboard = keyboards.main_menu_keyboard(
        has_business_account=has_business_account, is_admin=is_admin_user(tg_user.id)
    )
    await update.effective_message.reply_text(texts.MAIN_MENU_TITLE, reply_markup=keyboard)


async def show_connect_info(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.effective_message.reply_text(
        texts.CONNECT_ACCOUNT_INTRO, reply_markup=keyboards.back_to_menu_keyboard()
    )


async def show_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    with get_session() as session:
        free_limit = get_free_rule_limit(session)
        pro_limit = get_pro_rule_limit(session)
        template = get_help_text_template(session)
    text = texts.safe_format(template, free_limit=free_limit, pro_limit=pro_limit)
    await update.effective_message.reply_text(text, reply_markup=keyboards.back_to_menu_keyboard())


async def show_account_info(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    tg_user = update.effective_user
    with get_session() as session:
        user = get_or_create_user(session, telegram_user_id=tg_user.id)
        accounts = get_business_accounts_for_user(session, user.id)
        if not accounts:
            await update.effective_message.reply_text(
                texts.NO_BUSINESS_CONNECTION, reply_markup=keyboards.back_to_menu_keyboard()
            )
            return

        account = accounts[0]  # نسخه فعلی MVP: هر کاربر یک Business Account اصلی دارد.
        if business_account_is_pro(account):
            expires_at = format_iran(account.pro_until)
            days_left = fa_digits(days_left_until(account.pro_until))
            is_max = account.plan == PlanType.PRO_MAX
            rule_limit_text = (
                texts.ACCOUNT_RULE_LIMIT_UNLIMITED
                if is_max
                else texts.ACCOUNT_RULE_LIMIT_LIMITED.format(limit=get_rule_limit_for_account(session, account))
            )
            upgrade_note = texts.ACCOUNT_UPGRADE_NOTE_PRO_MAX if is_max else texts.ACCOUNT_UPGRADE_NOTE_PRO
            text = texts.ACCOUNT_INFO_PRO.format(
                plan_icon="🚀" if is_max else "⭐",
                plan="PRO MAX" if is_max else "PRO",
                expires_at=expires_at,
                days_left=days_left,
                rule_limit_text=rule_limit_text,
                upgrade_note=upgrade_note,
            )
        else:
            text = texts.ACCOUNT_INFO_FREE.format(rule_limit=get_free_rule_limit(session))

    await update.effective_message.reply_text(text, reply_markup=keyboards.back_to_menu_keyboard())


# --- خرید / ارتقای Pro و Pro Max ---


async def show_buy_pro(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    state.set_menu(context, state.MENU_BUY_PLAN_CHOICE)
    await update.effective_message.reply_text(
        texts.BUY_PRO_INFO, reply_markup=keyboards.buy_plan_choice_keyboard()
    )


async def handle_buy_plan_choice_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    mapping = {texts.BTN_PLAN_PRO: PlanType.PRO, texts.BTN_PLAN_PRO_MAX: PlanType.PRO_MAX}
    plan = mapping.get(text)
    if plan is None:
        return False

    with get_session() as session:
        options = list_pricing_options(session, plan=plan, only_enabled=True)
        if not options:
            await update.effective_message.reply_text(
                texts.BUY_NO_OPTIONS, reply_markup=keyboards.buy_plan_choice_keyboard()
            )
            return True

        context.user_data[state.BUY_SELECTED_PLAN] = plan.value
        state.set_menu(context, state.MENU_BUY_DURATION_CHOICE)
        plan_name = "Pro Max" if plan == PlanType.PRO_MAX else "Pro"
        await update.effective_message.reply_text(
            texts.BUY_DURATION_HEADER.format(plan=plan_name),
            reply_markup=keyboards.buy_duration_keyboard(options),
        )
    return True


async def handle_buy_duration_choice_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    pricing_id = keyboards.extract_id(text)
    if pricing_id is None:
        return False

    plan_value = context.user_data.get(state.BUY_SELECTED_PLAN, PlanType.PRO.value)
    with get_session() as session:
        option = get_pricing_option(session, pricing_id)
        if option is None:
            return False
        duration_days = option.duration_days
        price = option.price
        admin_username = get_admin_username(session)

    if not admin_username:
        await update.effective_message.reply_text(
            texts.ADMIN_USERNAME_NOT_SET, reply_markup=keyboards.back_to_menu_keyboard()
        )
        return True

    plan_name = "Pro Max" if plan_value == PlanType.PRO_MAX.value else "Pro"
    text_out = texts.PAY_CONTACT_ADMIN.format(
        plan=plan_name,
        duration=duration_days,
        admin_username=admin_username,
        price=price,
    )
    await update.effective_message.reply_text(text_out, reply_markup=keyboards.back_to_menu_keyboard())
    await show_main_menu(update, context)
    return True


async def buy_pro_contact_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """دکمه سراسری «💬 پیام به ادمین» از هر منویی — بدون پلن/مدت مشخص، پیام عمومی تماس با ادمین."""
    with get_session() as session:
        admin_username = get_admin_username(session)
    if not admin_username:
        await update.effective_message.reply_text(
            texts.ADMIN_USERNAME_NOT_SET, reply_markup=keyboards.back_to_menu_keyboard()
        )
        return
    await update.effective_message.reply_text(
        f"برای مشاوره خرید یا هر سوال دیگری، پیام دهید: https://t.me/{admin_username}",
        reply_markup=keyboards.back_to_menu_keyboard(),
    )
