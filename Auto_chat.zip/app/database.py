"""راه‌اندازی Engine و Session دیتابیس (SQLAlchemy 2.0)."""
from __future__ import annotations

from contextlib import contextmanager

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from app.config import settings
from app.models import Base

_connect_args = {}
if settings.database_url.startswith("sqlite"):
    # لازم برای استفاده از SQLite در محیط async/multi-thread (بات polling چند-ترد است).
    _connect_args = {"check_same_thread": False}

engine = create_engine(settings.database_url, connect_args=_connect_args, future=True)
# expire_on_commit=False (ریشه‌ی رفع کلاس کاملی از باگ‌ها): پیش‌فرض SQLAlchemy این است که
# با commit شدن session (که get_session() پایین همیشه در پایان بلوک with انجام می‌دهد)،
# تمام attributeهای آبجکت‌های خوانده‌شده «منقضی» (expired) شوند تا در دسترسی بعدی دوباره
# از دیتابیس خوانده شوند. اما در این پروژه، آبجکت‌ها (Rule، BusinessAccount،
# PricingPlan، ForceJoinChannel و ...) اغلب داخل یک `with get_session()` خوانده می‌شوند و
# بعد از بسته‌شدن همان بلوک (که session را می‌بندد) دوباره در ساخت پیام/کیبورد استفاده
# می‌شوند — چون خودِ ارسال پیام تلگرام (I/O شبکه) عمداً بیرون از session انجام می‌شود تا
# اتصال دیتابیس حین صبر برای شبکه باز نماند. با expire_on_commit پیش‌فرض (True)، هر کدام
# از این موارد با خطای `DetachedInstanceError` کرش می‌کرد (چند نمونه‌ی واقعی از آن در حین
# تست پیدا و جداگانه هم پچ شد: business_handlers.py، admin_handlers.py، rule_handlers.py،
# force_join.py). expire_on_commit=False یعنی مقادیر همان لحظه‌ی commit روی آبجکت باقی
# می‌مانند و خواندنشان بعد از بسته‌شدن session مشکلی ندارد — به شرطی که قبل از commit یک
# بار خوانده شده باشند (Lazy-load روی relationship هایی که اصلاً لمس نشده‌اند همچنان بعد
# از بسته‌شدن session کار نمی‌کند، برای همین در کد همچنان مقادیر لازم را در همان بلوک
# session می‌خوانیم/می‌سازیم — این تنظیم یک لایه محافظتی اضافه است، نه بهانه برای بی‌دقتی).
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True, expire_on_commit=False)


def init_db() -> None:
    """ساخت تمام جداول در صورت عدم وجود، به‌علاوه‌ی migration سبک برای ستون‌های
    جدیدی که به جدول‌های *موجود* اضافه شده‌اند."""
    Base.metadata.create_all(bind=engine)
    _run_lightweight_migrations()


# ستون‌هایی که بعد از انتشار اولیه‌ی این پروژه به مدل‌ها اضافه شده‌اند.
# Base.metadata.create_all فقط جدول‌های *جدید* را می‌سازد، نه ستون‌های جدید روی
# جدول‌های *موجود* — یعنی دیتابیسی که قبل از این تغییرات ساخته شده، بدون این
# migration سبک، همان لحظه‌ی اولین SELECT/INSERT با خطای
# «no such column» کرش می‌کند. این پروژه از Alembic استفاده نمی‌کند (خارج از
# scope یک MVP تک‌فایلی SQLite)، پس این تابع با ALTER TABLE دستی، ستون‌های
# گم‌شده را (فقط اگر واقعاً وجود نداشته باشند) اضافه می‌کند — کاملاً بی‌خطر روی
# دیتابیس تازه (چون از قبل توسط create_all ساخته شده‌اند) و ضروری برای
# دیتابیس‌های قدیمی‌تر واقعی که از قبل در حال استفاده هستند.
_EXPECTED_NEW_COLUMNS = {
    "business_accounts": [
        ("expiry_notice_sent", "BOOLEAN DEFAULT 0"),
        ("locked_rule_limit", "INTEGER"),
        ("disconnected_at", "DATETIME"),
    ],
}


def _run_lightweight_migrations() -> None:
    if not settings.database_url.startswith("sqlite"):
        # این migration سبک فقط برای SQLite (تنها دیتابیس رسمی پشتیبانی‌شده این
        # پروژه) نوشته شده؛ روی دیتابیس دیگری، بی‌خطر رد می‌شود تا کرش نکند.
        return
    with engine.begin() as conn:
        for table_name, columns in _EXPECTED_NEW_COLUMNS.items():
            existing = {row[1] for row in conn.exec_driver_sql(f"PRAGMA table_info({table_name})")}
            for column_name, column_def in columns:
                if column_name not in existing:
                    conn.exec_driver_sql(
                        f"ALTER TABLE {table_name} ADD COLUMN {column_name} {column_def}"
                    )
        # حذف کامل قابلیت FIRST_MESSAGE (درخواست ادمین): قوانین قدیمیِ این نوع از
        # دیتابیس‌های موجود پاک می‌شوند تا خواندن آن‌ها با enum جدید (EXACT /
        # CONTAINS) خطای LookupError ندهد. فقط نوع EXACT و CONTAINS پشتیبانی می‌شود.
        conn.exec_driver_sql("DELETE FROM rules WHERE trigger_type = 'FIRST_MESSAGE'")


@contextmanager
def get_session():
    session: Session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
