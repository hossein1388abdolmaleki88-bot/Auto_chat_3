"""
مدل‌های دیتابیس (SQLAlchemy 2.0 style).

جداول:
    users                  کاربرانی که وارد ربات شده‌اند (صاحبان کسب‌وکار)
    business_connections   اتصال Telegram Business هر کاربر به بات
    business_accounts      اطلاعات پلن/Pro هر کسب‌وکار (۱ به ۱ با business_connection)
    customer_chats         مشتریانی که به هر کسب‌وکار پیام داده‌اند
    rules                  قوانین پاسخ خودکار (Free داخلی + Pro اختصاصی)
    rule_media             عکس‌های متصل به هر Rule
    message_logs           لاگ پیام‌های ورودی/خروجی
    settings               تنظیمات کلی سیستم (قیمت Pro، مدت Pro، ...)
    pricing_plans          قیمت هر ترکیب پلن (Pro/Pro Max) × مدت، قابل ویرایش در پنل ادمین
    force_join_channels    کانال‌های عضویت اجباری
"""
from __future__ import annotations

import enum
from datetime import datetime, timezone

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    Enum as SAEnum,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


def utcnow() -> datetime:
    """
    زمان فعلی UTC به‌صورت naive (بدون tzinfo).

    توضیح مهم: SQLite (دیتابیس این MVP طبق بخش ۲۴ Specification) مقادیر datetime
    را به‌صورت متن ذخیره می‌کند و SQLAlchemy هنگام خواندن مجدد، اطلاعات tzinfo را
    برای آن حفظ نمی‌کند؛ در نتیجه مقایسه‌ی datetimeهای timezone-aware با مقادیر
    naive بازخوانی‌شده از دیتابیس می‌تواند خطای TypeError ایجاد کند. برای جلوگیری
    از این مشکل، در کل پروژه به‌صورت یکدست از UTC-naive استفاده می‌شود (همه مقادیر
    به‌طور ضمنی UTC هستند). اگر در آینده به دیتابیسی مثل PostgreSQL مهاجرت شود که
    timezone-aware datetime را به‌درستی نگه می‌دارد، این تابع و ستون‌های مرتبط
    باید به‌روزرسانی شوند.
    """
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Base(DeclarativeBase):
    pass


class PlanType(str, enum.Enum):
    FREE = "FREE"
    PRO = "PRO"
    PRO_MAX = "PRO_MAX"


class TriggerType(str, enum.Enum):
    EXACT = "EXACT"
    CONTAINS = "CONTAINS"


class ResponseMediaType(str, enum.Enum):
    NONE = "NONE"
    PHOTO = "PHOTO"
    MULTIPLE_PHOTOS = "MULTIPLE_PHOTOS"
    TEXT_AND_PHOTOS = "TEXT_AND_PHOTOS"


class MediaType(str, enum.Enum):
    PHOTO = "PHOTO"  # فعلاً فقط عکس؛ معماری برای انواع دیگر (فایل، ویدیو ...) قابل توسعه است.


class MessageDirection(str, enum.Enum):
    INCOMING = "INCOMING"
    OUTGOING = "OUTGOING"


class MessageStatus(str, enum.Enum):
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    IGNORED = "IGNORED"


class User(Base):
    """کاربری که وارد ربات شده (صاحب کسب‌وکار بالقوه یا بالفعل)."""

    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    telegram_user_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True)
    username: Mapped[str | None] = mapped_column(String(255), nullable=True)
    first_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    last_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=utcnow, onupdate=utcnow
    )

    business_accounts: Mapped[list["BusinessAccount"]] = relationship(back_populates="owner")


class BusinessConnection(Base):
    """اتصال فعال/غیرفعال Telegram Business بین کاربر و بات (خروجی آپدیت business_connection)."""

    __tablename__ = "business_connections"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    business_connection_id: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    telegram_user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    can_reply: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=utcnow, onupdate=utcnow
    )

    business_account: Mapped["BusinessAccount | None"] = relationship(
        back_populates="connection", uselist=False
    )


class BusinessAccount(Base):
    """اطلاعات پلن یک کسب‌وکار. هر اتصال Business دقیقاً یک BusinessAccount دارد."""

    __tablename__ = "business_accounts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    owner_user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    business_connection_id: Mapped[int] = mapped_column(
        ForeignKey("business_connections.id"), unique=True
    )
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    plan: Mapped[PlanType] = mapped_column(SAEnum(PlanType), default=PlanType.FREE)
    pro_until: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    # وقتی یک بار به کاربر «اعتبارت رو به اتمامه» گفته شد True می‌شود تا اسپم نشود؛
    # هر بار Pro/Pro Max فعال یا تمدید می‌شود دوباره False می‌شود.
    expiry_notice_sent: Mapped[bool] = mapped_column(Boolean, default=False)
    # سقف تعداد قانون اختصاصی «قفل‌شده» برای دوره‌ی فعلی این اکانت — همان لحظه‌ای
    # که پلن این اکانت شروع می‌شود (ساخت اکانت تازه با پلن Free، خرید/تمدید
    # Pro، یا انقضا و بازگشت به Free) از تنظیمات سراسری فعلی خوانده و اینجا
    # ثابت می‌شود. اگر ادمین بعداً سقف سراسری را عوض کند، این عدد دست‌نخورده
    # می‌ماند تا دوره‌ی فعلی این اکانت تمام شود (پایان Pro/Pro Max فعلی، یا
    # خرید/تمدید بعدی) — نه اینکه فوراً روی همه اعمال شود.
    # None برای ردیف‌های قدیمی‌تر (قبل از این ستون) به معنای «هنوز قفل نشده»
    # است؛ اولین باری که خوانده شود، با مقدار زنده‌ی فعلی قفل می‌شود
    # (به get_rule_limit_for_account در repository.py مراجعه کنید). برای پلن
    # Pro Max همیشه نادیده گرفته می‌شود (Pro Max ذاتاً نامحدود است).
    locked_rule_limit: Mapped[int | None] = mapped_column(Integer, nullable=True, default=None)
    # «غیرفعال‌سازی نرم»: وقتی کاربر دسترسی بات را از داخل تلگرام قطع می‌کند
    # (business_connection با is_enabled=False)، به‌جای حذف فوری، اینجا زمان قطع
    # ثبت می‌شود و اکانت از لیست «کاربران» ادمین حذف می‌شود؛ ولی قوانین، چت‌های
    # مشتری و وضعیت پلن حفظ می‌شود تا اگر کاربر تا DISCONNECT_GRACE_DAYS (۳۰ روز)
    # دوباره وصل شد، همه‌چیز بازیابی شود. بعد از گذشت این مهلت بدون بازگشت،
    # job پاک‌سازی (purge_disconnected_accounts) اکانت را حذف کامل می‌کند.
    # None یعنی اتصال فعال است.
    disconnected_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True, default=None)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=utcnow, onupdate=utcnow
    )

    owner: Mapped["User"] = relationship(back_populates="business_accounts")
    connection: Mapped["BusinessConnection"] = relationship(back_populates="business_account")
    rules: Mapped[list["Rule"]] = relationship(back_populates="business_account", cascade="all, delete-orphan")
    customer_chats: Mapped[list["CustomerChat"]] = relationship(
        back_populates="business_account", cascade="all, delete-orphan"
    )

    def is_pro_active(self, now: datetime | None = None) -> bool:
        now = now or utcnow()
        if self.plan not in (PlanType.PRO, PlanType.PRO_MAX):
            return False
        if self.pro_until is None:
            return False
        # هر دو مقدار UTC-naive هستند (به توضیح utcnow() مراجعه شود).
        pro_until = self.pro_until.replace(tzinfo=None) if self.pro_until.tzinfo else self.pro_until
        return pro_until > now

    def is_pro_max_active(self, now: datetime | None = None) -> bool:
        return self.plan == PlanType.PRO_MAX and self.is_pro_active(now)


class CustomerChat(Base):
    """مشتری‌ای که به یک کسب‌وکار پیام داده (برای آمار گفتگوهای هر مشتری)."""

    __tablename__ = "customer_chats"
    __table_args__ = (
        UniqueConstraint("business_account_id", "telegram_chat_id", name="uq_business_chat"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    business_account_id: Mapped[int] = mapped_column(ForeignKey("business_accounts.id"))
    telegram_chat_id: Mapped[int] = mapped_column(BigInteger, index=True)
    first_message_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    last_message_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    message_count: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=utcnow, onupdate=utcnow
    )

    business_account: Mapped["BusinessAccount"] = relationship(back_populates="customer_chats")


class Rule(Base):
    """یک قانون پاسخ‌گویی خودکار."""

    __tablename__ = "rules"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    business_account_id: Mapped[int] = mapped_column(ForeignKey("business_accounts.id"))
    trigger_type: Mapped[TriggerType] = mapped_column(SAEnum(TriggerType))
    trigger_value: Mapped[str | None] = mapped_column(String(500), nullable=True)
    response_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    response_media_type: Mapped[ResponseMediaType] = mapped_column(
        SAEnum(ResponseMediaType), default=ResponseMediaType.NONE
    )
    priority: Mapped[int] = mapped_column(Integer, default=0)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    is_system: Mapped[bool] = mapped_column(
        Boolean, default=False
    )  # Rule داخلی Free که کاربر نمی‌تواند حذف/ویرایش کند
    requires_pro: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=utcnow, onupdate=utcnow
    )

    business_account: Mapped["BusinessAccount"] = relationship(back_populates="rules")
    media_items: Mapped[list["RuleMedia"]] = relationship(
        back_populates="rule", cascade="all, delete-orphan", order_by="RuleMedia.sort_order"
    )


class RuleMedia(Base):
    """عکس (یا در آینده انواع دیگر مدیا) متصل به یک Rule."""

    __tablename__ = "rule_media"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    rule_id: Mapped[int] = mapped_column(ForeignKey("rules.id"))
    media_type: Mapped[MediaType] = mapped_column(SAEnum(MediaType), default=MediaType.PHOTO)
    telegram_file_id: Mapped[str] = mapped_column(String(500))
    sort_order: Mapped[int] = mapped_column(Integer, default=0)

    rule: Mapped["Rule"] = relationship(back_populates="media_items")


class MessageLog(Base):
    """لاگ هر پیام ورودی/خروجی برای دیباگ، آمار و جلوگیری از پردازش تکراری."""

    __tablename__ = "message_logs"
    __table_args__ = (
        UniqueConstraint(
            "business_account_id",
            "telegram_message_id",
            "direction",
            name="uq_message_dedup",
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    business_account_id: Mapped[int] = mapped_column(ForeignKey("business_accounts.id"))
    telegram_chat_id: Mapped[int] = mapped_column(BigInteger)
    telegram_message_id: Mapped[int] = mapped_column(BigInteger)
    direction: Mapped[MessageDirection] = mapped_column(SAEnum(MessageDirection))
    text: Mapped[str | None] = mapped_column(Text, nullable=True)
    matched_rule_id: Mapped[int | None] = mapped_column(ForeignKey("rules.id"), nullable=True)
    status: Mapped[MessageStatus] = mapped_column(SAEnum(MessageStatus))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Setting(Base):
    """تنظیمات کلید-مقدار سیستم (قیمت Pro، مدت Pro و غیره)."""

    __tablename__ = "settings"

    key: Mapped[str] = mapped_column(String(255), primary_key=True)
    value: Mapped[str] = mapped_column(Text)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=utcnow, onupdate=utcnow
    )


class PricingPlan(Base):
    """قیمت هر ترکیب (پلن Pro/Pro Max × مدت زمان) — کاملاً از پنل ادمین قابل تغییر.
    نمایش داده‌شده به کاربر در بخش «خرید Pro / Pro Max»."""

    __tablename__ = "pricing_plans"
    __table_args__ = (
        UniqueConstraint("plan", "duration_days", name="uq_plan_duration"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    plan: Mapped[PlanType] = mapped_column(SAEnum(PlanType))
    duration_days: Mapped[int] = mapped_column(Integer)
    price: Mapped[int] = mapped_column(Integer)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=utcnow, onupdate=utcnow
    )


class ForceJoinChannel(Base):
    """کانال‌های عضویت اجباری."""

    __tablename__ = "force_join_channels"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    channel_id: Mapped[str] = mapped_column(String(255))  # می‌تواند @username یا -100... باشد
    title: Mapped[str | None] = mapped_column(String(255), nullable=True)
    invite_link: Mapped[str | None] = mapped_column(String(500), nullable=True)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
